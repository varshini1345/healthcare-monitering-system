export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      appointments: {
        Row: {
          created_at: string
          date: string
          doctor_id: string
          end_time: string
          id: string
          notes: string | null
          patient_id: string
          reason: string
          start_time: string
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          date: string
          doctor_id: string
          end_time: string
          id?: string
          notes?: string | null
          patient_id: string
          reason: string
          start_time: string
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          date?: string
          doctor_id?: string
          end_time?: string
          id?: string
          notes?: string | null
          patient_id?: string
          reason?: string
          start_time?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "appointments_doctor_id_fkey"
            columns: ["doctor_id"]
            isOneToOne: false
            referencedRelation: "doctors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointments_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      comment_reactions: {
        Row: {
          comment_id: number
          created_at: string
          id: number
          type: number
          user_id: number
        }
        Insert: {
          comment_id: number
          created_at?: string
          id?: never
          type: number
          user_id: number
        }
        Update: {
          comment_id?: number
          created_at?: string
          id?: never
          type?: number
          user_id?: number
        }
        Relationships: [
          {
            foreignKeyName: "comment_reactions_ibfk_1"
            columns: ["comment_id"]
            isOneToOne: false
            referencedRelation: "comments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "comment_reactions_ibfk_2"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      comments: {
        Row: {
          anime_id: string
          content: string
          created_at: string
          episode_id: number
          id: number
          parent_id: number | null
          updated_at: string
          user_avatar: string | null
          user_id: number
          username: string | null
        }
        Insert: {
          anime_id: string
          content: string
          created_at?: string
          episode_id: number
          id?: never
          parent_id?: number | null
          updated_at?: string
          user_avatar?: string | null
          user_id: number
          username?: string | null
        }
        Update: {
          anime_id?: string
          content?: string
          created_at?: string
          episode_id?: number
          id?: never
          parent_id?: number | null
          updated_at?: string
          user_avatar?: string | null
          user_id?: number
          username?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fk_comments_parent"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "comments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_comments_user"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      doctors: {
        Row: {
          contact_number: string | null
          created_at: string
          education: string[] | null
          id: string
          license_number: string
          specialization: string
          updated_at: string
          user_id: string
          years_of_experience: number | null
        }
        Insert: {
          contact_number?: string | null
          created_at?: string
          education?: string[] | null
          id?: string
          license_number: string
          specialization: string
          updated_at?: string
          user_id: string
          years_of_experience?: number | null
        }
        Update: {
          contact_number?: string | null
          created_at?: string
          education?: string[] | null
          id?: string
          license_number?: string
          specialization?: string
          updated_at?: string
          user_id?: string
          years_of_experience?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "doctors_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "healthcare_users"
            referencedColumns: ["id"]
          },
        ]
      }
      healthcare_users: {
        Row: {
          auth_id: string | null
          avatar_url: string | null
          created_at: string
          email: string
          first_name: string
          id: string
          last_name: string
          role: string
          updated_at: string
        }
        Insert: {
          auth_id?: string | null
          avatar_url?: string | null
          created_at?: string
          email: string
          first_name: string
          id?: string
          last_name: string
          role: string
          updated_at?: string
        }
        Update: {
          auth_id?: string | null
          avatar_url?: string | null
          created_at?: string
          email?: string
          first_name?: string
          id?: string
          last_name?: string
          role?: string
          updated_at?: string
        }
        Relationships: []
      }
      medical_records: {
        Row: {
          created_at: string
          date: string
          description: string
          doctor_id: string
          id: string
          patient_id: string
          record_type: string
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          date: string
          description: string
          doctor_id: string
          id?: string
          patient_id: string
          record_type: string
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          date?: string
          description?: string
          doctor_id?: string
          id?: string
          patient_id?: string
          record_type?: string
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "medical_records_doctor_id_fkey"
            columns: ["doctor_id"]
            isOneToOne: false
            referencedRelation: "doctors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medical_records_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      medications: {
        Row: {
          created_at: string
          dosage: string
          duration: string
          frequency: string
          id: string
          name: string
          notes: string | null
          prescription_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          dosage: string
          duration: string
          frequency: string
          id?: string
          name: string
          notes?: string | null
          prescription_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          dosage?: string
          duration?: string
          frequency?: string
          id?: string
          name?: string
          notes?: string | null
          prescription_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "medications_prescription_id_fkey"
            columns: ["prescription_id"]
            isOneToOne: false
            referencedRelation: "prescriptions"
            referencedColumns: ["id"]
          },
        ]
      }
      pageview: {
        Row: {
          animeID: string
          dislike_count: number
          id: number
          like_count: number
          pageID: string
          totalview: number
        }
        Insert: {
          animeID: string
          dislike_count: number
          id?: never
          like_count: number
          pageID: string
          totalview: number
        }
        Update: {
          animeID?: string
          dislike_count?: number
          id?: never
          like_count?: number
          pageID?: string
          totalview?: number
        }
        Relationships: []
      }
      patients: {
        Row: {
          allergies: string[] | null
          blood_type: string | null
          contact_number: string | null
          created_at: string
          date_of_birth: string
          emergency_contact_name: string | null
          emergency_contact_number: string | null
          emergency_contact_relationship: string | null
          gender: string
          id: string
          medical_conditions: string[] | null
          updated_at: string
          user_id: string
        }
        Insert: {
          allergies?: string[] | null
          blood_type?: string | null
          contact_number?: string | null
          created_at?: string
          date_of_birth: string
          emergency_contact_name?: string | null
          emergency_contact_number?: string | null
          emergency_contact_relationship?: string | null
          gender: string
          id?: string
          medical_conditions?: string[] | null
          updated_at?: string
          user_id: string
        }
        Update: {
          allergies?: string[] | null
          blood_type?: string | null
          contact_number?: string | null
          created_at?: string
          date_of_birth?: string
          emergency_contact_name?: string | null
          emergency_contact_number?: string | null
          emergency_contact_relationship?: string | null
          gender?: string
          id?: string
          medical_conditions?: string[] | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "patients_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "healthcare_users"
            referencedColumns: ["id"]
          },
        ]
      }
      prescriptions: {
        Row: {
          created_at: string
          date: string
          diagnosis: string
          doctor_id: string
          id: string
          instructions: string | null
          patient_id: string
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          date: string
          diagnosis: string
          doctor_id: string
          id?: string
          instructions?: string | null
          patient_id: string
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          date?: string
          diagnosis?: string
          doctor_id?: string
          id?: string
          instructions?: string | null
          patient_id?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "prescriptions_doctor_id_fkey"
            columns: ["doctor_id"]
            isOneToOne: false
            referencedRelation: "doctors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "prescriptions_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      users: {
        Row: {
          anime_count: number | null
          anime_episodes: number | null
          avatar_url: string | null
          created_at: string
          custom_avatar: number | null
          email: string
          id: number
          image: string | null
          manga_chapters: number | null
          manga_count: number | null
          password: string
          username: string
        }
        Insert: {
          anime_count?: number | null
          anime_episodes?: number | null
          avatar_url?: string | null
          created_at?: string
          custom_avatar?: number | null
          email: string
          id?: never
          image?: string | null
          manga_chapters?: number | null
          manga_count?: number | null
          password: string
          username: string
        }
        Update: {
          anime_count?: number | null
          anime_episodes?: number | null
          avatar_url?: string | null
          created_at?: string
          custom_avatar?: number | null
          email?: string
          id?: never
          image?: string | null
          manga_chapters?: number | null
          manga_count?: number | null
          password?: string
          username?: string
        }
        Relationships: []
      }
      watch_history: {
        Row: {
          anilist_id: string | null
          anime_id: string
          anime_name: string
          created_at: string
          dub_count: number | null
          episode_number: number
          id: number
          poster: string | null
          sub_count: number | null
          updated_at: string
          user_id: number
          watched_episodes: string | null
        }
        Insert: {
          anilist_id?: string | null
          anime_id: string
          anime_name: string
          created_at: string
          dub_count?: number | null
          episode_number: number
          id?: never
          poster?: string | null
          sub_count?: number | null
          updated_at: string
          user_id: number
          watched_episodes?: string | null
        }
        Update: {
          anilist_id?: string | null
          anime_id?: string
          anime_name?: string
          created_at?: string
          dub_count?: number | null
          episode_number?: number
          id?: never
          poster?: string | null
          sub_count?: number | null
          updated_at?: string
          user_id?: number
          watched_episodes?: string | null
        }
        Relationships: []
      }
      watched_episode: {
        Row: {
          anilist_id: number | null
          anime_id: string
          episodes_watched: string
          id: number
          updated_at: string | null
          user_id: number
        }
        Insert: {
          anilist_id?: number | null
          anime_id: string
          episodes_watched: string
          id?: never
          updated_at?: string | null
          user_id: number
        }
        Update: {
          anilist_id?: number | null
          anime_id?: string
          episodes_watched?: string
          id?: never
          updated_at?: string | null
          user_id?: number
        }
        Relationships: []
      }
      watchlist: {
        Row: {
          anilist_id: number | null
          anime_id: string | null
          anime_name: string
          anime_type: string | null
          created_at: string
          dub_count: number | null
          duration: string | null
          id: number
          poster: string | null
          sub_count: number | null
          type: number
          updated_at: string
          user_id: number
        }
        Insert: {
          anilist_id?: number | null
          anime_id?: string | null
          anime_name: string
          anime_type?: string | null
          created_at?: string
          dub_count?: number | null
          duration?: string | null
          id?: never
          poster?: string | null
          sub_count?: number | null
          type: number
          updated_at?: string
          user_id: number
        }
        Update: {
          anilist_id?: number | null
          anime_id?: string | null
          anime_name?: string
          anime_type?: string | null
          created_at?: string
          dub_count?: number | null
          duration?: string | null
          id?: never
          poster?: string | null
          sub_count?: number | null
          type?: number
          updated_at?: string
          user_id?: number
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
