
// This file now provides a mock client for compatibility with existing code
// The actual data is now stored in localStorage

const mockClient = {
  auth: {
    signInWithPassword: async () => {
      throw new Error('Supabase client has been removed. Use localStorageService instead.');
    },
    signUp: async () => {
      throw new Error('Supabase client has been removed. Use localStorageService instead.');
    },
    signOut: async () => {
      throw new Error('Supabase client has been removed. Use localStorageService instead.');
    },
    getSession: async () => {
      return { data: { session: null } };
    },
    onAuthStateChange: () => {
      return {
        data: {
          subscription: {
            unsubscribe: () => {}
          }
        }
      };
    }
  },
  from: () => {
    return {
      select: () => {
        return {
          eq: () => {
            return {
              single: async () => {
                throw new Error('Supabase client has been removed. Use localStorageService instead.');
              }
            };
          }
        };
      },
      insert: () => {
        return {
          select: () => {
            return {
              single: async () => {
                throw new Error('Supabase client has been removed. Use localStorageService instead.');
              }
            };
          }
        };
      }
    };
  }
};

export const supabase = mockClient as any;
