import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { toast } from '@/components/ui/use-toast';
import { getUsers, saveUser, getUsersByRole, generateUUID } from '@/services/localStorageService';
import { HealthcareUser, UserRole } from '@/types/healthcare';

interface AuthContextType {
  user: HealthcareUser | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  register: (userData: Omit<HealthcareUser, 'id' | 'auth_id' | 'created_at' | 'updated_at'>) => Promise<void>;
  loading: boolean;
  isLoading: boolean;
  isAuthenticated: boolean;
  signup: (email: string, password: string, userData: {
    first_name: string;
    last_name: string;
    role: UserRole;
  }) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<HealthcareUser | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const navigate = useNavigate();
  const location = useLocation();

  // Computed property for authentication status
  const isAuthenticated = user !== null;
  const isLoading = loading;

  useEffect(() => {
    // Check for stored user on initial load
    const storedUser = localStorage.getItem('healthcare_current_user');
    if (storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser);
        setUser(parsedUser);
      } catch (error) {
        console.error('Error parsing stored user:', error);
        localStorage.removeItem('healthcare_current_user');
      }
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    // Redirect unauthenticated users
    if (!loading && !user && location.pathname !== '/login') {
      navigate('/login');
    }
  }, [user, loading, navigate, location.pathname]);

  const login = async (email: string, password: string): Promise<void> => {
    try {
      const users = getUsers();
      const matchedUser = users.find(
        (u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password
      );

      if (matchedUser) {
        setUser(matchedUser);
        localStorage.setItem('healthcare_current_user', JSON.stringify(matchedUser));
        
        // Add a toast for successful login
        toast({
          title: "Login Successful",
          description: `Welcome back, ${matchedUser.first_name}!`,
        });
        
        navigate('/dashboard');
      } else {
        // If user doesn't exist, check if we should create a demo account
        const demoAccountCreated = localStorage.getItem('demo_account_created');
        
        if (!demoAccountCreated && email.includes('demo')) {
          // Create a demo account only once
          toast({
            title: "Creating Demo Account",
            description: "Creating a demo account for testing purposes"
          });
          
          const newUser: HealthcareUser = {
            id: generateUUID(),
            auth_id: generateUUID(),
            email: email,
            password: password,
            first_name: 'Demo',
            last_name: 'User',
            role: 'doctor' as UserRole,
            avatar_url: null,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          };
          
          saveUser(newUser);
          localStorage.setItem('demo_account_created', 'true');
          
          // Log in with the newly created account
          setUser(newUser);
          localStorage.setItem('healthcare_current_user', JSON.stringify(newUser));
          
          toast({
            title: "Demo Account Created",
            description: "You've been logged in with a demo account"
          });
          
          navigate('/dashboard');
        } else {
          toast({
            title: "Login Failed",
            description: "Invalid login credentials",
            variant: "destructive"
          });
          throw new Error('Invalid login credentials');
        }
      }
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  };

  const signup = async (email: string, password: string, userData: {
    first_name: string;
    last_name: string;
    role: UserRole;
  }): Promise<void> => {
    try {
      // Check if email already exists
      const users = getUsers();
      const emailExists = users.some(u => u.email.toLowerCase() === email.toLowerCase());
      
      if (emailExists) {
        toast({
          title: "Registration Failed",
          description: "Email is already registered",
          variant: "destructive"
        });
        throw new Error('Email is already registered');
      }
      
      // Generate IDs
      const id = generateUUID();
      const auth_id = generateUUID();
      
      // Create new user object
      const newUser: HealthcareUser = {
        id,
        auth_id,
        email,
        password,
        first_name: userData.first_name,
        last_name: userData.last_name,
        role: userData.role,
        avatar_url: null,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      // Save user
      saveUser(newUser);
      
      // Auto login after registration
      setUser(newUser);
      localStorage.setItem('healthcare_current_user', JSON.stringify(newUser));
      
      // Mark demo account as created if this is a demo account
      if (email.includes('demo')) {
        localStorage.setItem('demo_account_created', 'true');
      }
      
      // Redirect to dashboard
      navigate('/dashboard');
    } catch (error) {
      console.error('Registration error:', error);
      throw error;
    }
  };

  const register = async (userData: Omit<HealthcareUser, 'id' | 'auth_id' | 'created_at' | 'updated_at'>): Promise<void> => {
    try {
      // Check if email already exists
      const users = getUsers();
      const emailExists = users.some(u => u.email.toLowerCase() === userData.email.toLowerCase());
      
      if (emailExists) {
        toast({
          title: "Registration Failed",
          description: "Email is already registered",
          variant: "destructive"
        });
        throw new Error('Email is already registered');
      }
      
      // Generate IDs
      const id = generateUUID();
      const auth_id = generateUUID();
      
      // Create new user object
      const newUser: HealthcareUser = {
        ...userData,
        id,
        auth_id,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      // Save user
      saveUser(newUser);
      
      // Auto login after registration
      setUser(newUser);
      localStorage.setItem('healthcare_current_user', JSON.stringify(newUser));
      
      // Redirect to dashboard
      navigate('/dashboard');
    } catch (error) {
      console.error('Registration error:', error);
      throw error;
    }
  };

  const logout = (): void => {
    setUser(null);
    localStorage.removeItem('healthcare_current_user');
    navigate('/login');
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      login, 
      logout, 
      register, 
      loading,
      isLoading,
      isAuthenticated,
      signup 
    }}>
      {children}
    </AuthContext.Provider>
  );
};
