import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useIsMobile } from '@/hooks/use-mobile';
import { 
  LayoutDashboard, 
  Calendar, 
  FileText, 
  Users, 
  Pill, 
  Settings, 
  LogOut, 
  BarChart4, 
  MessageSquare,
  Clock
} from 'lucide-react';

interface NavItem {
  title: string;
  href: string;
  icon: React.ReactNode;
  roles: string[];
}

const navItems: NavItem[] = [
  {
    title: 'Dashboard',
    href: '/dashboard',
    icon: <LayoutDashboard className="h-5 w-5" />,
    roles: ['admin', 'doctor', 'patient', 'pharmacist', 'receptionist'],
  },
  {
    title: 'Appointments',
    href: '/appointments',
    icon: <Calendar className="h-5 w-5" />,
    roles: ['admin', 'doctor', 'patient', 'receptionist'],
  },
  {
    title: 'Medical Records',
    href: '/medical-records',
    icon: <FileText className="h-5 w-5" />,
    roles: ['admin', 'doctor', 'patient'],
  },
  {
    title: 'Patients',
    href: '/patients',
    icon: <Users className="h-5 w-5" />,
    roles: ['admin', 'doctor', 'receptionist'],
  },
  {
    title: 'Prescriptions',
    href: '/prescriptions',
    icon: <Pill className="h-5 w-5" />,
    roles: ['admin', 'doctor', 'patient', 'pharmacist'],
  },
  {
    title: 'Analytics',
    href: '/analytics',
    icon: <BarChart4 className="h-5 w-5" />,
    roles: ['admin'],
  },
  {
    title: 'Chat',
    href: '/chat',
    icon: <MessageSquare className="h-5 w-5" />,
    roles: ['admin', 'doctor', 'patient'],
  },
  {
    title: 'Schedule',
    href: '/schedule',
    icon: <Clock className="h-5 w-5" />,
    roles: ['doctor', 'receptionist'],
  },
  {
    title: 'Settings',
    href: '/settings',
    icon: <Settings className="h-5 w-5" />,
    roles: ['admin', 'doctor', 'patient', 'pharmacist', 'receptionist'],
  },
];

const Sidebar = () => {
  const { user, logout } = useAuth();
  const location = useLocation();
  const isMobile = useIsMobile();

  if (!user) return null;

  const filteredNavItems = navItems.filter(item => item.roles.includes(user.role));

  return (
    <aside className="flex flex-col h-full bg-white border-r border-gray-200">
      <div className={`p-4 border-b ${isMobile ? 'pt-16' : ''}`}>
        {!isMobile && (
          <Link to="/dashboard" className="flex items-center gap-2">
            <div className="flex items-center justify-center w-8 h-8 rounded-md bg-primary text-white font-bold">
              H
            </div>
            <span className="text-lg font-semibold text-gray-900">HealthLink Nexus</span>
          </Link>
        )}
      </div>

      <div className="flex items-center gap-3 p-4 border-b">
        <Avatar className="h-10 w-10">
          <AvatarImage src={user.avatar_url} alt={`${user.first_name} ${user.last_name}`} />
          <AvatarFallback className="bg-primary text-white">
            {user.first_name.charAt(0)}
            {user.last_name.charAt(0)}
          </AvatarFallback>
        </Avatar>
        <div className="flex flex-col">
          <span className="text-sm font-medium text-gray-900">{user.first_name} {user.last_name}</span>
          <span className="text-xs text-gray-500 capitalize">{user.role}</span>
        </div>
      </div>

      <ScrollArea className="flex-1 py-2">
        <nav className="flex flex-col gap-1 px-2">
          {filteredNavItems.map((item) => (
            <Link
              key={item.href}
              to={item.href}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-3 text-sm font-medium transition-colors",
                "active:scale-[0.98] active:opacity-80",
                location.pathname === item.href || location.pathname.startsWith(`${item.href}/`)
                  ? "bg-primary text-white"
                  : "text-gray-700 hover:bg-gray-100"
              )}
            >
              {item.icon}
              {item.title}
            </Link>
          ))}
        </nav>
      </ScrollArea>

      <div className="p-4 border-t mt-auto">
        <Button
          variant="ghost"
          className="w-full flex items-center justify-center gap-2 text-gray-700 py-3"
          onClick={logout}
        >
          <LogOut className="w-4 h-4" />
          <span>Log out</span>
        </Button>
      </div>
    </aside>
  );
};

export default Sidebar;
