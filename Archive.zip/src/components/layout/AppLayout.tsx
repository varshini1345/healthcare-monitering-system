import React, { useState, useEffect } from 'react';
import { Outlet, Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import Sidebar from './Sidebar';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useIsMobile } from '@/hooks/use-mobile';

const AppLayout = () => {
  const { user, isLoading: loading } = useAuth();
  const isLoading = loading;
  const isAuthenticated = !!user;
  const isMobile = useIsMobile();
  const [showSidebar, setShowSidebar] = useState(!isMobile);

  // Close sidebar by default on mobile
  useEffect(() => {
    if (isMobile) {
      setShowSidebar(false);
    } else {
      setShowSidebar(true);
    }
  }, [isMobile]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-lg text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return (
    <div className="min-h-screen bg-gray-50 relative flex w-full">
      {/* Mobile header */}
      {isMobile && (
        <div className="fixed top-0 left-0 right-0 z-30 bg-white p-4 border-b shadow-sm">
          <div className="flex justify-between items-center">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setShowSidebar(!showSidebar)}
              className="z-30 p-2"
            >
              {showSidebar ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
            <h1 className="text-lg font-semibold">HealthLink Nexus</h1>
            <div className="w-5"></div> {/* Spacer for centering */}
          </div>
        </div>
      )}
      
      {/* Overlay for mobile */}
      <div 
        className={`fixed inset-0 bg-black/50 z-20 transition-opacity duration-300 ease-in-out ${
          showSidebar && isMobile ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`} 
        onClick={() => setShowSidebar(false)}
      />
      
      {/* Sidebar */}
      <div 
        className={`
          fixed top-0 left-0 h-full z-20 bg-white transition-all duration-300 ease-in-out 
          ${isMobile ? 'w-[85%] max-w-[300px]' : 'w-64'} 
          ${isMobile && !showSidebar ? '-translate-x-full' : 'translate-x-0'}
          shadow-lg
        `}
      >
        <Sidebar />
      </div>
      
      {/* Main content */}
      <main 
        className={`transition-all duration-300 flex-1 ${
          isMobile ? 'ml-0 pt-16' : 'ml-64'
        }`}
      >
        <div className="p-4 md:p-6 max-w-7xl mx-auto">
          <Outlet />
        </div>
      </main>
    </div>
  );
};

export default AppLayout;
