import { ChatMessage, HealthcareUser } from '@/types/healthcare';

const MESSAGES_KEY = 'healthcare_messages';
const USERS_KEY = 'healthcare_users';

// Helper function to get messages from local storage
const getMessages = (): ChatMessage[] => {
  try {
    const messages = localStorage.getItem(MESSAGES_KEY);
    return messages ? JSON.parse(messages) : [];
  } catch (error) {
    console.error('Error retrieving messages from localStorage:', error);
    return [];
  }
};

// Save messages to local storage
const saveMessages = (messages: ChatMessage[]): void => {
  try {
    localStorage.setItem(MESSAGES_KEY, JSON.stringify(messages));
  } catch (error) {
    console.error('Error saving messages to localStorage:', error);
  }
};

// Get users from local storage
const getUsers = (): HealthcareUser[] => {
  try {
    const users = localStorage.getItem(USERS_KEY);
    return users ? JSON.parse(users) : [];
  } catch (error) {
    console.error('Error retrieving users from localStorage:', error);
    return [];
  }
};

// Get messages between two users
const getUserMessages = (userId1: string, userId2: string): ChatMessage[] => {
  const allMessages = getMessages();
  return allMessages.filter(
    message => (message.senderId === userId1 && message.recipientId === userId2) || 
               (message.senderId === userId2 && message.recipientId === userId1)
  ).sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
};

// Send a new message
const sendMessage = (senderId: string, recipientId: string, content: string): ChatMessage => {
  const allMessages = getMessages();
  
  const newMessage: ChatMessage = {
    id: generateUUID(),
    senderId,
    recipientId,
    content,
    read: false,
    created_at: new Date().toISOString()
  };
  
  allMessages.push(newMessage);
  saveMessages(allMessages);
  
  return newMessage;
};

// Mark messages as read
const markMessagesAsRead = (senderId: string, recipientId: string): void => {
  const allMessages = getMessages();
  
  const updatedMessages = allMessages.map(message => {
    if (message.senderId === senderId && message.recipientId === recipientId && !message.read) {
      return { ...message, read: true };
    }
    return message;
  });
  
  saveMessages(updatedMessages);
};

// Get unread message count
const getUnreadMessageCount = (userId: string): number => {
  const allMessages = getMessages();
  return allMessages.filter(message => message.recipientId === userId && !message.read).length;
};

// Helper function to generate UUIDs
const generateUUID = () => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

// Get all contacts for a user based on their role
const getUserContacts = (userId: string, userRole: string): HealthcareUser[] => {
  const allUsers = getUsers();
  const currentUser = allUsers.find(user => user.id === userId);
  
  if (!currentUser) return [];
  
  // Return all users except the current user - this ensures all users can chat with each other
  return allUsers.filter(contact => contact.id !== userId);
};

// Initialize empty chat messages
const initializeDefaultMessages = (): void => {
  localStorage.setItem(MESSAGES_KEY, JSON.stringify([]));
};

export {
  getMessages,
  getUserMessages,
  sendMessage,
  markMessagesAsRead,
  getUnreadMessageCount,
  getUserContacts,
  initializeDefaultMessages
};
