import { 
  HealthcareUser, 
  Patient, 
  Doctor, 
  Appointment, 
  Prescription, 
  MedicalRecord,
  Medication,
  ChatMessage,
  SymptomReport
} from '@/types/healthcare';

// Storage keys
const STORAGE_KEYS = {
  USERS: 'healthcare_users',
  PATIENTS: 'healthcare_patients',
  DOCTORS: 'healthcare_doctors',
  APPOINTMENTS: 'healthcare_appointments',
  PRESCRIPTIONS: 'healthcare_prescriptions',
  MEDICAL_RECORDS: 'healthcare_medical_records',
  MEDICATIONS: 'healthcare_medications',
  CHAT_MESSAGES: 'healthcare_chat_messages',
  SYMPTOM_REPORTS: 'healthcare_symptom_reports'
};

// Generate a UUID
export const generateUUID = (): string => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

// Initialize local storage with default data
export const initializeLocalStorage = () => {
  // Clear all existing data
  Object.values(STORAGE_KEYS).forEach(key => {
    localStorage.removeItem(key);
  });

  // Create only admin user
  const adminUser: HealthcareUser = {
    id: generateUUID(),
    auth_id: generateUUID(),
    email: 'admin@healthlink.com',
    password: 'password123',
    first_name: 'Admin',
    last_name: 'User',
    role: 'admin',
    avatar_url: null,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  };
  
  // Save only admin user
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify([adminUser]));
  
  // Initialize empty arrays for all other data
  localStorage.setItem(STORAGE_KEYS.DOCTORS, JSON.stringify([]));
  localStorage.setItem(STORAGE_KEYS.PATIENTS, JSON.stringify([]));
  localStorage.setItem(STORAGE_KEYS.APPOINTMENTS, JSON.stringify([]));
  localStorage.setItem(STORAGE_KEYS.PRESCRIPTIONS, JSON.stringify([]));
  localStorage.setItem(STORAGE_KEYS.MEDICAL_RECORDS, JSON.stringify([]));
  localStorage.setItem(STORAGE_KEYS.MEDICATIONS, JSON.stringify([]));
  localStorage.setItem(STORAGE_KEYS.CHAT_MESSAGES, JSON.stringify([]));
  localStorage.setItem(STORAGE_KEYS.SYMPTOM_REPORTS, JSON.stringify([]));
};

// Data access functions

// Users
export const getUsers = (): HealthcareUser[] => {
  try {
    const users = localStorage.getItem(STORAGE_KEYS.USERS);
    return users ? JSON.parse(users) : [];
  } catch (error) {
    console.error('Error getting users:', error);
    return [];
  }
};

export const getUserById = (id: string): HealthcareUser | null => {
  const users = getUsers();
  return users.find(user => user.id === id) || null;
};

export const getUsersByRole = (role: string): HealthcareUser[] => {
  const users = getUsers();
  return users.filter(user => user.role === role);
};

export const saveUser = (user: HealthcareUser): HealthcareUser => {
  const users = getUsers();
  const existingUserIndex = users.findIndex(u => u.id === user.id);
  
  if (existingUserIndex >= 0) {
    // Update existing user
    users[existingUserIndex] = { ...user, updated_at: new Date().toISOString() };
  } else {
    // Add new user
    users.push({ ...user, created_at: new Date().toISOString(), updated_at: new Date().toISOString() });
  }
  
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  return user;
};

// Patients
export const getPatients = (): Patient[] => {
  try {
    const patients = localStorage.getItem(STORAGE_KEYS.PATIENTS);
    return patients ? JSON.parse(patients) : [];
  } catch (error) {
    console.error('Error getting patients:', error);
    return [];
  }
};

export const getPatientById = (id: string): Patient | null => {
  const patients = getPatients();
  return patients.find(patient => patient.id === id) || null;
};

export const getPatientByUserId = (userId: string): Patient | null => {
  const patients = getPatients();
  return patients.find(patient => patient.userId === userId) || null;
};

export const getPatientsByDoctorId = (doctorId: string): Patient[] => {
  const patients = getPatients();
  return patients.filter(patient => patient.assignedDoctor === doctorId);
};

export const savePatient = (patient: Patient): Patient => {
  const patients = getPatients();
  const existingPatientIndex = patients.findIndex(p => p.id === patient.id);
  
  if (existingPatientIndex >= 0) {
    // Update existing patient
    patients[existingPatientIndex] = { ...patient, updated_at: new Date().toISOString() };
  } else {
    // Add new patient
    patients.push({ ...patient, created_at: new Date().toISOString(), updated_at: new Date().toISOString() });
  }
  
  localStorage.setItem(STORAGE_KEYS.PATIENTS, JSON.stringify(patients));
  return patient;
};

export const assignDoctorToPatient = (patientId: string, doctorId: string): Patient | null => {
  const patients = getPatients();
  const patientIndex = patients.findIndex(p => p.id === patientId);
  
  if (patientIndex >= 0) {
    patients[patientIndex] = { 
      ...patients[patientIndex], 
      assignedDoctor: doctorId,
      updated_at: new Date().toISOString()
    };
    localStorage.setItem(STORAGE_KEYS.PATIENTS, JSON.stringify(patients));
    
    // Update doctor's patient count
    const doctors = getDoctors();
    const doctorIndex = doctors.findIndex(d => d.userId === doctorId);
    if (doctorIndex >= 0) {
      const currentCount = doctors[doctorIndex].patientCount || 0;
      doctors[doctorIndex] = {
        ...doctors[doctorIndex],
        patientCount: currentCount + 1,
        updated_at: new Date().toISOString()
      };
      localStorage.setItem(STORAGE_KEYS.DOCTORS, JSON.stringify(doctors));
    }
    
    return patients[patientIndex];
  }
  
  return null;
};

// Symptom reports
export const getSymptomReports = (): SymptomReport[] => {
  try {
    const reports = localStorage.getItem(STORAGE_KEYS.SYMPTOM_REPORTS);
    return reports ? JSON.parse(reports) : [];
  } catch (error) {
    console.error('Error getting symptom reports:', error);
    return [];
  }
};

export const getSymptomReportById = (id: string): SymptomReport | null => {
  const reports = getSymptomReports();
  return reports.find(report => report.id === id) || null;
};

export const getSymptomReportsByPatientId = (patientId: string): SymptomReport[] => {
  const reports = getSymptomReports();
  return reports.filter(report => report.patientId === patientId);
};

export const saveSymptomReport = (report: SymptomReport): SymptomReport => {
  const reports = getSymptomReports();
  const existingReportIndex = reports.findIndex(r => r.id === report.id);
  
  if (existingReportIndex >= 0) {
    // Update existing report
    reports[existingReportIndex] = { ...report, updated_at: new Date().toISOString() };
  } else {
    // Add new report
    reports.push({ ...report, created_at: new Date().toISOString(), updated_at: new Date().toISOString() });
  }
  
  localStorage.setItem(STORAGE_KEYS.SYMPTOM_REPORTS, JSON.stringify(reports));
  return report;
};

// Doctors
export const getDoctors = (): Doctor[] => {
  try {
    const doctors = localStorage.getItem(STORAGE_KEYS.DOCTORS);
    return doctors ? JSON.parse(doctors) : [];
  } catch (error) {
    console.error('Error getting doctors:', error);
    return [];
  }
};

export const getDoctorById = (id: string): Doctor | null => {
  const doctors = getDoctors();
  return doctors.find(doctor => doctor.id === id) || null;
};

export const getDoctorByUserId = (userId: string): Doctor | null => {
  const doctors = getDoctors();
  return doctors.find(doctor => doctor.userId === userId) || null;
};

export const getAvailableDoctors = (): Doctor[] => {
  const doctors = getDoctors();
  return doctors.filter(doctor => doctor.availability === 'available');
};

export const saveDoctor = (doctor: Doctor): Doctor => {
  const doctors = getDoctors();
  const existingDoctorIndex = doctors.findIndex(d => d.id === doctor.id);
  
  if (existingDoctorIndex >= 0) {
    // Update existing doctor
    doctors[existingDoctorIndex] = { ...doctor, updated_at: new Date().toISOString() };
  } else {
    // Add new doctor
    doctors.push({ ...doctor, created_at: new Date().toISOString(), updated_at: new Date().toISOString() });
  }
  
  localStorage.setItem(STORAGE_KEYS.DOCTORS, JSON.stringify(doctors));
  return doctor;
};

// Appointments
export const getAppointments = (): Appointment[] => {
  try {
    const appointments = localStorage.getItem(STORAGE_KEYS.APPOINTMENTS);
    return appointments ? JSON.parse(appointments) : [];
  } catch (error) {
    console.error('Error getting appointments:', error);
    return [];
  }
};

export const getAppointmentById = (id: string): Appointment | null => {
  const appointments = getAppointments();
  return appointments.find(appointment => appointment.id === id) || null;
};

export const getAppointmentsByPatientId = (patientId: string): Appointment[] => {
  const appointments = getAppointments();
  return appointments.filter(appointment => appointment.patientId === patientId);
};

export const getAppointmentsByDoctorId = (doctorId: string): Appointment[] => {
  const appointments = getAppointments();
  return appointments.filter(appointment => appointment.doctorId === doctorId);
};

export const saveAppointment = (appointment: Appointment): Appointment => {
  const appointments = getAppointments();
  const existingAppointmentIndex = appointments.findIndex(a => a.id === appointment.id);
  
  if (existingAppointmentIndex >= 0) {
    // Update existing appointment
    appointments[existingAppointmentIndex] = { ...appointment, updated_at: new Date().toISOString() };
  } else {
    // Add new appointment
    appointments.push({ ...appointment, created_at: new Date().toISOString(), updated_at: new Date().toISOString() });
  }
  
  localStorage.setItem(STORAGE_KEYS.APPOINTMENTS, JSON.stringify(appointments));
  return appointment;
};

// Prescriptions
export const getPrescriptions = (): Prescription[] => {
  try {
    const prescriptions = localStorage.getItem(STORAGE_KEYS.PRESCRIPTIONS);
    return prescriptions ? JSON.parse(prescriptions) : [];
  } catch (error) {
    console.error('Error getting prescriptions:', error);
    return [];
  }
};

export const getPrescriptionById = (id: string): Prescription | null => {
  const prescriptions = getPrescriptions();
  return prescriptions.find(prescription => prescription.id === id) || null;
};

export const getPrescriptionsByPatientId = (patientId: string): Prescription[] => {
  const prescriptions = getPrescriptions();
  return prescriptions.filter(prescription => prescription.patientId === patientId);
};

export const getPrescriptionsByDoctorId = (doctorId: string): Prescription[] => {
  const prescriptions = getPrescriptions();
  return prescriptions.filter(prescription => prescription.doctorId === doctorId);
};

export const savePrescription = (prescription: Prescription): Prescription => {
  const prescriptions = getPrescriptions();
  const existingPrescriptionIndex = prescriptions.findIndex(p => p.id === prescription.id);
  
  if (existingPrescriptionIndex >= 0) {
    // Update existing prescription
    prescriptions[existingPrescriptionIndex] = { ...prescription, updated_at: new Date().toISOString() };
  } else {
    // Add new prescription
    prescriptions.push({ ...prescription, created_at: new Date().toISOString(), updated_at: new Date().toISOString() });
  }
  
  localStorage.setItem(STORAGE_KEYS.PRESCRIPTIONS, JSON.stringify(prescriptions));
  return prescription;
};

// Medical Records
export const getMedicalRecords = (): MedicalRecord[] => {
  try {
    const records = localStorage.getItem(STORAGE_KEYS.MEDICAL_RECORDS);
    return records ? JSON.parse(records) : [];
  } catch (error) {
    console.error('Error getting medical records:', error);
    return [];
  }
};

export const getMedicalRecordById = (id: string): MedicalRecord | null => {
  const records = getMedicalRecords();
  return records.find(record => record.id === id) || null;
};

export const getMedicalRecordsByPatientId = (patientId: string): MedicalRecord[] => {
  const records = getMedicalRecords();
  return records.filter(record => record.patientId === patientId);
};

export const getMedicalRecordsByDoctorId = (doctorId: string): MedicalRecord[] => {
  const records = getMedicalRecords();
  return records.filter(record => record.doctorId === doctorId);
};

export const saveMedicalRecord = (record: MedicalRecord): MedicalRecord => {
  const records = getMedicalRecords();
  const existingRecordIndex = records.findIndex(r => r.id === record.id);
  
  if (existingRecordIndex >= 0) {
    // Update existing record
    records[existingRecordIndex] = { ...record, updated_at: new Date().toISOString() };
  } else {
    // Add new record
    records.push({ ...record, created_at: new Date().toISOString(), updated_at: new Date().toISOString() });
  }
  
  localStorage.setItem(STORAGE_KEYS.MEDICAL_RECORDS, JSON.stringify(records));
  return record;
};

// Medications
export const getMedications = (): Medication[] => {
  try {
    const medications = localStorage.getItem(STORAGE_KEYS.MEDICATIONS);
    return medications ? JSON.parse(medications) : [];
  } catch (error) {
    console.error('Error getting medications:', error);
    return [];
  }
};

export const getMedicationById = (id: string): Medication | null => {
  const medications = getMedications();
  return medications.find(medication => medication.id === id) || null;
};

export const getMedicationsByCategory = (category: string): Medication[] => {
  const medications = getMedications();
  return medications.filter(medication => medication.category === category);
};

export const saveMedication = (medication: Medication): Medication => {
  const medications = getMedications();
  const existingMedicationIndex = medications.findIndex(m => m.id === medication.id);
  
  if (existingMedicationIndex >= 0) {
    // Update existing medication
    medications[existingMedicationIndex] = { ...medication, updated_at: new Date().toISOString() };
  } else {
    // Add new medication
    medications.push({ ...medication, created_at: new Date().toISOString(), updated_at: new Date().toISOString() });
  }
  
  localStorage.setItem(STORAGE_KEYS.MEDICATIONS, JSON.stringify(medications));
  return medication;
};

// Chat Messages
export const getChatMessages = (): ChatMessage[] => {
  try {
    const messages = localStorage.getItem(STORAGE_KEYS.CHAT_MESSAGES);
    return messages ? JSON.parse(messages) : [];
  } catch (error) {
    console.error('Error getting chat messages:', error);
    return [];
  }
};

export const getUserConversations = (userId: string): ChatMessage[] => {
  const messages = getChatMessages();
  return messages.filter(msg => msg.senderId === userId || msg.recipientId === userId);
};

export const getConversationBetweenUsers = (userId1: string, userId2: string): ChatMessage[] => {
  const messages = getChatMessages();
  return messages.filter(
    msg => (msg.senderId === userId1 && msg.recipientId === userId2) || 
           (msg.senderId === userId2 && msg.recipientId === userId1)
  ).sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
};

export const saveChatMessage = (message: Omit<ChatMessage, 'id' | 'created_at'>): ChatMessage => {
  const messages = getChatMessages();
  
  const newMessage: ChatMessage = {
    ...message,
    id: generateUUID(),
    created_at: new Date().toISOString()
  };
  
  messages.push(newMessage);
  localStorage.setItem(STORAGE_KEYS.CHAT_MESSAGES, JSON.stringify(messages));
  return newMessage;
};

export const markMessagesAsRead = (senderId: string, recipientId: string): void => {
  const messages = getChatMessages();
  const updatedMessages = messages.map(msg => {
    if (msg.senderId === senderId && msg.recipientId === recipientId && !msg.read) {
      return { ...msg, read: true };
    }
    return msg;
  });
  
  localStorage.setItem(STORAGE_KEYS.CHAT_MESSAGES, JSON.stringify(updatedMessages));
};

// Get dashboard data for a user
export const getDashboardData = (userId: string) => {
  const user = getUserById(userId);
  
  if (!user) {
    throw new Error('User not found');
  }
  
  // Get data based on user role
  switch (user.role) {
    case 'admin': {
      // For admin, show overall statistics
      const allPatients = getPatients();
      const allAppointments = getAppointments();
      const upcomingAppointments = allAppointments
        .filter(app => app.status === 'scheduled' && new Date(app.date) >= new Date())
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
        .slice(0, 5);
      
      // Get all users with patient role
      const allPatientUsers = getUsersByRole('patient');
      
      // Active cases: patients with at least one scheduled or ongoing appointment
      const activeCasesSet = new Set(
        allAppointments
          .filter(app => app.status === 'scheduled' && new Date(app.date) >= new Date())
          .map(app => app.patientId)
      );
      const activeCasesCount = activeCasesSet.size;

      // Pending tasks: appointments with status 'scheduled' or prescriptions with status 'sent'
      const pendingAppointments = allAppointments.filter(app => app.status === 'scheduled' && new Date(app.date) >= new Date());
      const pendingPrescriptions = getPrescriptions().filter(p => p.status === 'sent');
      const pendingTasksCount = pendingAppointments.length + pendingPrescriptions.length;
      
      // Generate recent activities
      const activities = [
        ...allAppointments.map(app => ({
          id: generateUUID(),
          type: 'appointment' as const,
          description: `Appointment scheduled with Dr. ${getUserById(app.doctorId)?.last_name || 'Unknown'} and patient ${getUserById(app.patientId)?.last_name || 'Unknown'}`,
          timestamp: app.created_at
        })),
        ...getPrescriptions().map(pres => ({
          id: generateUUID(),
          type: 'prescription' as const,
          description: `Prescription created by Dr. ${getUserById(pres.doctorId)?.last_name || 'Unknown'} for ${getUserById(pres.patientId)?.last_name || 'Unknown'}`,
          timestamp: pres.created_at
        }))
      ]
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 10);
      
      return {
        appointmentsCount: allAppointments.length,
        patientsCount: allPatientUsers.length, // Show total registered patients
        upcomingAppointments,
        recentActivities: activities,
        activeCasesCount,
        pendingTasksCount
      };
    }
    case 'doctor': {
      // For doctor, show assigned patients and appointments
      const doctor = getDoctorByUserId(userId);
      
      // If no doctor profile exists, create a default one
      if (!doctor) {
        const newDoctor: Doctor = {
          id: generateUUID(),
          userId: userId,
          specialization: 'General Medicine',
          licenseNumber: 'DEFAULT',
          yearsOfExperience: 0,
          education: 'MD',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          availability: 'available'
        };
        saveDoctor(newDoctor);
      }
      
      const assignedPatients = getPatients().filter(p => p.assignedDoctor === userId);
      const doctorAppointments = getAppointments().filter(app => app.doctorId === userId);
      const upcomingAppointments = doctorAppointments
        .filter(app => app.status === 'scheduled' && new Date(app.date) >= new Date())
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
        .slice(0, 5);
      
      // Get all users with patient role
      const allPatientUsers = getUsersByRole('patient');
      
      // Active cases: assigned patients with at least one scheduled appointment
      const activeCasesSet = new Set(
        doctorAppointments
          .filter(app => app.status === 'scheduled' && new Date(app.date) >= new Date())
          .map(app => app.patientId)
      );
      const activeCasesCount = activeCasesSet.size;

      // Pending tasks: scheduled appointments or sent prescriptions for this doctor
      const pendingAppointments = doctorAppointments.filter(app => app.status === 'scheduled' && new Date(app.date) >= new Date());
      const pendingPrescriptions = getPrescriptionsByDoctorId(userId).filter(p => p.status === 'sent');
      const pendingTasksCount = pendingAppointments.length + pendingPrescriptions.length;
      
      // Generate recent activities
      const activities = [
        ...doctorAppointments.map(app => ({
          id: generateUUID(),
          type: 'appointment' as const,
          description: `Appointment with ${getUserById(app.patientId)?.first_name || 'Unknown'} ${getUserById(app.patientId)?.last_name || 'Unknown'}`,
          timestamp: app.created_at
        })),
        ...getPrescriptionsByDoctorId(userId).map(pres => ({
          id: generateUUID(),
          type: 'prescription' as const,
          description: `Prescription created for ${getUserById(pres.patientId)?.first_name || 'Unknown'} ${getUserById(pres.patientId)?.last_name || 'Unknown'}`,
          timestamp: pres.created_at
        })),
        ...getSymptomReports()
          .filter(report => {
            const patient = getPatientById(report.patientId);
            return patient?.assignedDoctor === userId;
          })
          .map(report => ({
            id: generateUUID(),
            type: 'symptom' as const,
            description: `New symptom reported by ${getUserById(getPatientById(report.patientId)?.userId || '')?.first_name || 'Unknown'} ${getUserById(getPatientById(report.patientId)?.userId || '')?.last_name || 'Unknown'}`,
            timestamp: report.created_at
          }))
      ]
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 10);
      
      return {
        appointmentsCount: doctorAppointments.length,
        patientsCount: allPatientUsers.length, // Show total registered patients
        upcomingAppointments,
        recentActivities: activities,
        activeCasesCount,
        pendingTasksCount
      };
    }
    case 'patient': {
      // For patient, show own appointments and prescriptions
      const patient = getPatientByUserId(userId);
      
      // If no patient profile exists, create a default one
      if (!patient) {
        const newPatient: Patient = {
          id: generateUUID(),
          userId: userId,
          dateOfBirth: new Date().toISOString(),
          gender: 'other',
          allergies: [],
          medicalConditions: [],
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          newForRoles: {
            admin: true,
            doctor: true,
            paramist: true
          }
        };
        savePatient(newPatient);
      }
      
      const patientAppointments = getAppointments().filter(app => app.patientId === userId);
      const upcomingAppointments = patientAppointments
        .filter(app => app.status === 'scheduled' && new Date(app.date) >= new Date())
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
        .slice(0, 5);
      
      // Get all users with patient role
      const allPatientUsers = getUsersByRole('patient');
      
      // Active cases: if patient has at least one scheduled appointment
      const activeCasesCount = patientAppointments.some(app => app.status === 'scheduled' && new Date(app.date) >= new Date()) ? 1 : 0;

      // Pending tasks: scheduled appointments or sent prescriptions for this patient
      const pendingAppointments = patientAppointments.filter(app => app.status === 'scheduled' && new Date(app.date) >= new Date());
      const pendingPrescriptions = getPrescriptionsByPatientId(userId).filter(p => p.status === 'sent');
      const pendingTasksCount = pendingAppointments.length + pendingPrescriptions.length;
      
      // Generate recent activities
      const activities = [
        ...patientAppointments.map(app => ({
          id: generateUUID(),
          type: 'appointment' as const,
          description: `Appointment with Dr. ${getUserById(app.doctorId)?.last_name || 'Unknown'}`,
          timestamp: app.created_at
        })),
        ...getPrescriptionsByPatientId(userId).map(pres => ({
          id: generateUUID(),
          type: 'prescription' as const,
          description: `Prescription from Dr. ${getUserById(pres.doctorId)?.last_name || 'Unknown'} for ${pres.diagnosis}`,
          timestamp: pres.created_at
        })),
        ...getSymptomReportsByPatientId(userId).map(report => ({
          id: generateUUID(),
          type: 'symptom' as const,
          description: `Reported symptoms: ${report.description}`,
          timestamp: report.created_at
        }))
      ]
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 10);
      
      return {
        appointmentsCount: patientAppointments.length,
        patientsCount: allPatientUsers.length, // Show total registered patients
        upcomingAppointments,
        recentActivities: activities,
        activeCasesCount,
        pendingTasksCount
      };
    }
    case 'pharmacist': {
      // For pharmacist, show prescriptions data
      const prescriptions = getPrescriptions();
      const filledPrescriptions = prescriptions.filter(p => p.status === 'filled' || p.status === 'completed');
      const pendingPrescriptions = prescriptions.filter(p => p.status === 'sent');
      
      const upcomingAppointments = []; // Pharmacists don't have appointments
      
      // Get all users with patient role
      const allPatientUsers = getUsersByRole('patient');
      
      // Active cases: patients with at least one prescription not completed
      const activeCasesSet = new Set(
        prescriptions
          .filter(p => p.status !== 'completed')
          .map(p => p.patientId)
      );
      const activeCasesCount = activeCasesSet.size;

      // Pending tasks: prescriptions with status 'sent'
      const pendingTasksCount = pendingPrescriptions.length;
      
      // Generate recent activities
      const activities = prescriptions
        .map(pres => ({
          id: generateUUID(),
          type: 'prescription' as const,
          description: `${pres.status === 'filled' ? 'Filled' : pres.status === 'completed' ? 'Completed' : 'Received'} prescription for ${getUserById(pres.patientId)?.first_name || 'Unknown'} ${getUserById(pres.patientId)?.last_name || 'Unknown'}`,
          timestamp: pres.updated_at
        }))
        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
        .slice(0, 10);
      
      return {
        appointmentsCount: pendingPrescriptions.length,
        patientsCount: allPatientUsers.length, // Show total registered patients
        upcomingAppointments,
        recentActivities: activities,
        activeCasesCount,
        pendingTasksCount
      };
    }
    case 'receptionist': {
      // For receptionist, show appointment scheduling data
      const allAppointments = getAppointments();
      const upcomingAppointments = allAppointments
        .filter(app => app.status === 'scheduled' && new Date(app.date) >= new Date())
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
        .slice(0, 5);
      
      // Get all users with patient role
      const allPatientUsers = getUsersByRole('patient');
      
      // Active cases: patients with at least one scheduled appointment
      const activeCasesSet = new Set(
        allAppointments
          .filter(app => app.status === 'scheduled' && new Date(app.date) >= new Date())
          .map(app => app.patientId)
      );
      const activeCasesCount = activeCasesSet.size;

      // Pending tasks: scheduled appointments or sent prescriptions
      const pendingAppointments = allAppointments.filter(app => app.status === 'scheduled' && new Date(app.date) >= new Date());
      const pendingPrescriptions = getPrescriptions().filter(p => p.status === 'sent');
      const pendingTasksCount = pendingAppointments.length + pendingPrescriptions.length;
      
      // Generate recent activities
      const activities = allAppointments
        .map(app => ({
          id: generateUUID(),
          type: 'appointment' as const,
          description: `Appointment for ${getUserById(app.patientId)?.first_name || 'Unknown'} ${getUserById(app.patientId)?.last_name || 'Unknown'} with Dr. ${getUserById(app.doctorId)?.last_name || 'Unknown'}`,
          timestamp: app.created_at
        }))
        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
        .slice(0, 10);
      
      return {
        appointmentsCount: allAppointments.length,
        patientsCount: allPatientUsers.length, // Show total registered patients
        upcomingAppointments,
        recentActivities: activities,
        activeCasesCount,
        pendingTasksCount
      };
    }
    default:
      return null;
  }
};
