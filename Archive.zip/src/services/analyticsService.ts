
import { Appointment, Patient, Prescription, MedicalRecord, AnalyticsData, MonthlyData, DemographicData } from '@/types/healthcare';

const APPOINTMENTS_KEY = 'healthcare_appointments';
const PATIENTS_KEY = 'healthcare_patients';
const PRESCRIPTIONS_KEY = 'healthcare_prescriptions';
const MEDICAL_RECORDS_KEY = 'healthcare_medical_records';

// Helper function to get data from local storage
const getLocalStorageData = <T>(key: string): T[] => {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error(`Error retrieving ${key} from localStorage:`, error);
    return [];
  }
};

// Get appointments data
const getAppointments = (): Appointment[] => {
  return getLocalStorageData<Appointment>(APPOINTMENTS_KEY);
};

// Get patients data
const getPatients = (): Patient[] => {
  return getLocalStorageData<Patient>(PATIENTS_KEY);
};

// Get prescriptions data
const getPrescriptions = (): Prescription[] => {
  return getLocalStorageData<Prescription>(PRESCRIPTIONS_KEY);
};

// Get medical records data
const getMedicalRecords = (): MedicalRecord[] => {
  return getLocalStorageData<MedicalRecord>(MEDICAL_RECORDS_KEY);
};

// Calculate appointments per month
const getAppointmentsTrend = (): MonthlyData[] => {
  const appointments = getAppointments();
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  
  // Initialize the monthly data
  const monthlyData = months.map(month => ({
    month,
    appointments: 0
  }));
  
  // Count appointments per month
  appointments.forEach(appointment => {
    const date = new Date(appointment.date);
    const monthIndex = date.getMonth();
    monthlyData[monthIndex].appointments = (monthlyData[monthIndex].appointments || 0) + 1;
  });
  
  return monthlyData;
};

// Calculate patient demographics
const getPatientDemographics = (): DemographicData[] => {
  const patients = getPatients();
  
  // Group patients by age ranges
  const ageGroups: { [key: string]: number } = {
    '0-18': 0,
    '19-35': 0,
    '36-50': 0,
    '51-65': 0,
    '65+': 0
  };
  
  patients.forEach(patient => {
    if (patient.dateOfBirth) {
      const birthDate = new Date(patient.dateOfBirth);
      const today = new Date();
      const age = today.getFullYear() - birthDate.getFullYear();
      
      if (age <= 18) ageGroups['0-18'] += 1;
      else if (age <= 35) ageGroups['19-35'] += 1;
      else if (age <= 50) ageGroups['36-50'] += 1;
      else if (age <= 65) ageGroups['51-65'] += 1;
      else ageGroups['65+'] += 1;
    }
  });
  
  // Convert to array format for charts
  return Object.entries(ageGroups).map(([name, value]) => ({ name, value }));
};

// Calculate revenue data (based on prescriptions and appointments)
const getRevenueData = (): MonthlyData[] => {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const appointments = getAppointments();
  const prescriptions = getPrescriptions();
  
  // Initialize the monthly data
  const monthlyData = months.map(month => ({
    month,
    revenue: 0
  }));
  
  // Assume each appointment costs $100
  appointments.forEach(appointment => {
    const date = new Date(appointment.date);
    const monthIndex = date.getMonth();
    monthlyData[monthIndex].revenue = (monthlyData[monthIndex].revenue || 0) + 100;
  });
  
  // Assume each prescription costs $50
  prescriptions.forEach(prescription => {
    const date = new Date(prescription.date);
    const monthIndex = date.getMonth();
    monthlyData[monthIndex].revenue = (monthlyData[monthIndex].revenue || 0) + 50;
  });
  
  return monthlyData;
};

// Get all analytics data
const getAnalyticsData = (): AnalyticsData => {
  return {
    appointmentsTrend: getAppointmentsTrend(),
    patientDemographics: getPatientDemographics(),
    revenueData: getRevenueData()
  };
};

// Count total patients
const getTotalPatients = (): number => {
  return getPatients().length;
};

// Count total appointments
const getTotalAppointments = (): number => {
  return getAppointments().length;
};

// Calculate total revenue
const getTotalRevenue = (): number => {
  return getRevenueData().reduce((total, month) => total + (month.revenue || 0), 0);
};

export {
  getAnalyticsData,
  getTotalPatients,
  getTotalAppointments,
  getTotalRevenue,
  getAppointmentsTrend,
  getPatientDemographics,
  getRevenueData
};
