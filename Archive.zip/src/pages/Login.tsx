
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { cn } from '@/lib/utils';
import { UserRole } from '@/types/healthcare';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Eye, EyeOff, LogIn, UserPlus } from 'lucide-react';

// Demo accounts for testing
const loginCredentials = {
  admin: { email: "admin@healthlink.com", password: "password123" },
  doctor: { email: "doctor@healthlink.com", password: "password123" },
  patient: { email: "patient@healthlink.com", password: "password123" },
  pharmacist: { email: "pharmacist@healthlink.com", password: "password123" },
  receptionist: { email: "receptionist@healthlink.com", password: "password123" }
};

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [role, setRole] = useState<UserRole>('patient');
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [isCreatingDemo, setIsCreatingDemo] = useState(false);
  
  const { login, signup, isLoading, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  
  // If already authenticated, redirect to dashboard
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, navigate]);

  const handleRoleSelect = (role: UserRole) => {
    setSelectedRole(role);
    setEmail(loginCredentials[role].email);
    setPassword(loginCredentials[role].password);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    
    try {
      if (isRegisterMode) {
        if (password !== confirmPassword) {
          setErrorMsg('Passwords do not match');
          return;
        }
        
        await signup(email, password, {
          first_name: firstName,
          last_name: lastName,
          role: role
        });
        
        // No need to login after signup as it's handled in the signup function
      } else {
        await login(email, password);
      }
    } catch (error: any) {
      console.error('Auth error:', error);
      setErrorMsg(error.message || 'Failed to authenticate. Please check your credentials.');
    }
  };

  const handleCreateDemoAccount = async () => {
    setIsCreatingDemo(true);
    setErrorMsg('');

    try {
      const selectedDemoRole = selectedRole || 'patient';
      const demoUser = loginCredentials[selectedDemoRole];
      
      // Generate a unique email to avoid conflicts
      const timestamp = new Date().getTime();
      const uniqueEmail = `${selectedDemoRole}_${timestamp}@healthlink.com`;
      
      console.log('Creating demo account with:', {
        email: uniqueEmail,
        password: demoUser.password,
        first_name: selectedDemoRole.charAt(0).toUpperCase() + selectedDemoRole.slice(1),
        last_name: 'Demo'
      });

      await signup(
        uniqueEmail, 
        demoUser.password,
        {
          first_name: selectedDemoRole.charAt(0).toUpperCase() + selectedDemoRole.slice(1),
          last_name: 'Demo',
          role: selectedDemoRole
        }
      );
      
      // Login happens automatically after signup
    } catch (error: any) {
      console.error('Demo account creation error:', error);
      setErrorMsg(error.message || 'Failed to create demo account.');
    } finally {
      setIsCreatingDemo(false);
    }
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const toggleAuthMode = () => {
    setIsRegisterMode(!isRegisterMode);
    setErrorMsg('');
    // Clear fields when toggling
    if (!isRegisterMode) {
      setSelectedRole(null);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-healthcare-blue bg-opacity-10 p-4">
      <div className="w-full max-w-3xl">
        <div className="text-center mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">HealthLink Nexus Platform</h1>
          <p className="text-gray-600">Connecting healthcare professionals and patients seamlessly</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
          <div className="md:col-span-2 bg-white rounded-lg shadow-lg p-6">
            <div className="mb-6">
              <h2 className="text-2xl font-semibold text-gray-900 mb-2">
                {isRegisterMode ? 'Register' : 'Login'}
              </h2>
              <p className="text-gray-600 text-sm">
                {isRegisterMode 
                  ? 'Create your healthcare account' 
                  : 'Access your healthcare dashboard'}
              </p>
            </div>
            
            {errorMsg && (
              <Alert variant="destructive" className="mb-4">
                <AlertDescription>{errorMsg}</AlertDescription>
              </Alert>
            )}
            
            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                {isRegisterMode && (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="firstName">First Name</Label>
                        <Input
                          id="firstName"
                          value={firstName}
                          onChange={(e) => setFirstName(e.target.value)}
                          placeholder="First Name"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lastName">Last Name</Label>
                        <Input
                          id="lastName"
                          value={lastName}
                          onChange={(e) => setLastName(e.target.value)}
                          placeholder="Last Name"
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="role">Role</Label>
                      <select
                        id="role"
                        value={role}
                        onChange={(e) => setRole(e.target.value as UserRole)}
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        required
                      >
                        <option value="patient">Patient</option>
                        <option value="doctor">Doctor</option>
                        <option value="pharmacist">Pharmacist</option>
                        <option value="receptionist">Receptionist</option>
                        <option value="admin">Admin</option>
                      </select>
                    </div>
                  </>
                )}
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter your password"
                      required
                    />
                    <button
                      type="button"
                      onClick={togglePasswordVisibility}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                </div>
                
                {isRegisterMode && (
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirm Password</Label>
                    <div className="relative">
                      <Input
                        id="confirmPassword"
                        type={showPassword ? "text" : "password"}
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="Confirm your password"
                        required
                      />
                    </div>
                  </div>
                )}
                
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <span className="flex items-center">
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      {isRegisterMode ? 'Creating account...' : 'Signing in...'}
                    </span>
                  ) : (
                    <span className="flex items-center justify-center">
                      {isRegisterMode ? (
                        <><UserPlus className="mr-2 h-4 w-4" /> Register</>
                      ) : (
                        <><LogIn className="mr-2 h-4 w-4" /> Sign In</>
                      )}
                    </span>
                  )}
                </Button>
                
                <div className="text-center pt-2">
                  <Button
                    type="button"
                    variant="link"
                    onClick={toggleAuthMode}
                    className="text-primary"
                  >
                    {isRegisterMode
                      ? "Already have an account? Sign in"
                      : "Don't have an account? Register"}
                  </Button>
                </div>
              </div>
            </form>
          </div>
          
          {!isRegisterMode && (
            <div className="md:col-span-3">
              <Card className="h-full">
                <CardHeader>
                  <CardTitle>Test Accounts</CardTitle>
                  <CardDescription>
                    Select a role to automatically fill the login credentials
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <RadioGroup
                    value={selectedRole || ""}
                    onValueChange={(value) => handleRoleSelect(value as UserRole)}
                    className="grid grid-cols-1 sm:grid-cols-2 gap-4"
                  >
                    {Object.entries(loginCredentials).map(([role, credentials]) => (
                      <div key={role}>
                        <RadioGroupItem
                          value={role}
                          id={`role-${role}`}
                          className="sr-only"
                        />
                        <Label
                          htmlFor={`role-${role}`}
                          className={cn(
                            "flex flex-col items-center justify-between rounded-md border-2 border-muted p-4 hover:bg-accent hover:text-accent-foreground cursor-pointer",
                            selectedRole === role && "border-primary"
                          )}
                        >
                          <div className="mb-2 p-2 rounded-full bg-primary/10">
                            {role === "admin" && (
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><rect width="20" height="14" x="2" y="3" rx="2"/><line x1="8" x2="16" y1="21" y2="21"/><line x1="12" x2="12" y1="17" y2="21"/></svg>
                            )}
                            {role === "doctor" && (
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="M3 9a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9Z"/><path d="M8 7V3m8 4V3"/><path d="M12 12v3"/><path d="M9 13h6"/></svg>
                            )}
                            {role === "patient" && (
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                            )}
                            {role === "pharmacist" && (
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="m12.76 1.764.873-.19 1.404 6.508 1.532.341 1.39-6.242.875.194a.5.5 0 0 1 .394.587l-2.393 10.742a1.502 1.502 0 0 1-1.352 1.178l-.327.034a1.5 1.5 0 0 1-1.621-1.414l-.114-1.019-3.974-.883-.073.653a1.501 1.501 0 0 1-1.528 1.347l-.316-.035a1.501 1.501 0 0 1-1.345-1.627l1.099-10.82a.5.5 0 0 1 .55-.444l.877.095 1.555 7.062 3.174.706-.453-4.324-.875-.194-1.404-6.508.873-.19Z"/><ellipse cx="12" cy="21" rx="8" ry="2"/></svg>
                            )}
                            {role === "receptionist" && (
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                            )}
                          </div>
                          <span className="text-lg font-semibold capitalize mb-1">{role}</span>
                          <span className="text-xs text-gray-500 mb-2">{credentials.email}</span>
                          <div className="text-xs px-2 py-1 rounded bg-gray-100 text-gray-600">Password: {credentials.password}</div>
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                </CardContent>
                <CardFooter>
                  <div className="w-full">
                    <p className="text-sm text-gray-500 mb-3">
                      {selectedRole ? (
                        "You can use the shown credentials to log in, or create a new demo account with the button below."
                      ) : (
                        "Click any role above to pre-fill the login form with test credentials."
                      )}
                    </p>
                    <Button 
                      type="button"
                      onClick={handleCreateDemoAccount}
                      disabled={isCreatingDemo || !selectedRole}
                      className="w-full flex items-center justify-center"
                    >
                      {isCreatingDemo ? (
                        <span className="flex items-center">
                          <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Creating Demo Account...
                        </span>
                      ) : (
                        <>
                          <UserPlus className="mr-2 h-4 w-4" />
                          Create Demo Account
                        </>
                      )}
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Login;
