import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Search, Send, ChevronLeft } from 'lucide-react';
import { 
  getUserContacts, 
  getUserMessages, 
  sendMessage, 
  markMessagesAsRead 
} from '@/services/chatService';
import { ChatMessage, HealthcareUser } from '@/types/healthcare';
import { toast } from '@/components/ui/use-toast';
import { useIsMobile } from '@/hooks/use-mobile';

const Chat = () => {
  const { user } = useAuth();
  const [selectedUser, setSelectedUser] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [contacts, setContacts] = useState<HealthcareUser[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [showContactsList, setShowContactsList] = useState(true);
  const isMobile = useIsMobile();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (user) {
      fetchContacts();
    }
  }, [user]);

  useEffect(() => {
    if (user && selectedUser) {
      fetchMessages();
      
      // Set up periodic refresh
      const interval = setInterval(fetchMessages, 5000);
      return () => clearInterval(interval);
    }
  }, [user, selectedUser]);

  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  // On mobile, hide contacts list when a conversation is selected
  useEffect(() => {
    if (isMobile && selectedUser) {
      setShowContactsList(false);
    } else if (!isMobile) {
      setShowContactsList(true);
    }
  }, [selectedUser, isMobile]);

  const fetchContacts = () => {
    if (!user) return;
    
    try {
      const userContacts = getUserContacts(user.id, user.role);
      setContacts(userContacts);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching contacts:', error);
      toast({
        title: "Error",
        description: "Failed to load contacts",
        variant: "destructive"
      });
      setLoading(false);
    }
  };

  const fetchMessages = () => {
    if (!user || !selectedUser) return;
    
    try {
      const userMessages = getUserMessages(user.id, selectedUser);
      setMessages(userMessages);
      
      // Mark messages as read
      markMessagesAsRead(selectedUser, user.id);
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const handleSendMessage = () => {
    if (!message.trim() || !selectedUser || !user) return;

    try {
      const newMessage = sendMessage(user.id, selectedUser, message.trim());
      setMessages(prev => [...prev, newMessage]);
      setMessage('');
    } catch (error) {
      console.error('Error sending message:', error);
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive"
      });
    }
  };

  const handleSelectContact = (contactId: string) => {
    setSelectedUser(contactId);
    if (isMobile) {
      setShowContactsList(false);
    }
  };

  const handleBackToContacts = () => {
    setShowContactsList(true);
  };

  // Filter contacts based on search query
  const filteredContacts = contacts.filter(contact =>
    searchQuery ? 
      `${contact.first_name} ${contact.last_name}`.toLowerCase().includes(searchQuery.toLowerCase()) :
      true
  );

  // Helper function to format timestamp
  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (!user) return null;

  if (loading) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-lg text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  const selectedContact = contacts.find(c => c.id === selectedUser);

  return (
    <div className="fade-in">
      <div className="mb-6">
        <h2 className="text-3xl font-bold tracking-tight mb-2">Messages</h2>
        <p className="text-muted-foreground">Chat with healthcare providers and patients</p>
      </div>

      <Card className="h-[calc(100vh-220px)] sm:h-[70vh]">
        <div className="grid grid-cols-1 md:grid-cols-3 h-full">
          {/* Contacts List - Show on desktop or when in contacts view on mobile */}
          {(!isMobile || showContactsList) && (
            <div className="col-span-1 border-r h-full flex flex-col">
              <CardHeader className="pb-2 flex-shrink-0">
                <CardTitle>Conversations</CardTitle>
                <div className="relative my-2">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input 
                    placeholder="Search contacts..." 
                    className="pl-8" 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </CardHeader>
              
              <ScrollArea className="flex-1 px-4">
                {filteredContacts.length > 0 ? (
                  <div className="space-y-2 pb-4">
                    {filteredContacts.map(contact => {
                      // Find latest message
                      const userMessages = getUserMessages(user.id, contact.id);
                      const latestMessage = userMessages.length > 0 ? userMessages[userMessages.length - 1] : null;
                      
                      // Count unread messages
                      const unreadCount = userMessages.filter(
                        msg => msg.senderId === contact.id && msg.recipientId === user.id && !msg.read
                      ).length;
                      
                      return (
                        <div 
                          key={contact.id} 
                          className={`p-2 rounded-md cursor-pointer flex items-center gap-3 ${
                            selectedUser === contact.id ? 'bg-primary text-white' : 'hover:bg-muted/50'
                          }`}
                          onClick={() => handleSelectContact(contact.id)}
                        >
                          <Avatar className="h-10 w-10 flex-shrink-0">
                            <AvatarImage src={contact.avatar_url || undefined} alt={`${contact.first_name} ${contact.last_name}`} />
                            <AvatarFallback>
                              {contact.first_name.charAt(0)}
                              {contact.last_name.charAt(0)}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <p className={`font-medium truncate ${selectedUser === contact.id ? 'text-white' : ''}`}>
                                {contact.first_name} {contact.last_name}
                              </p>
                              {unreadCount > 0 && (
                                <span className={`px-1.5 py-0.5 text-xs font-medium rounded-full ${
                                  selectedUser === contact.id 
                                    ? 'bg-white text-primary' 
                                    : 'bg-primary text-white'
                                }`}>
                                  {unreadCount}
                                </span>
                              )}
                            </div>
                            {latestMessage && (
                              <div className="flex items-center gap-1">
                                <p className={`text-xs truncate ${
                                  selectedUser === contact.id ? 'text-white/80' : 'text-muted-foreground'
                                }`}>
                                  {latestMessage.senderId === user.id ? 'You: ' : ''}
                                  {latestMessage.content}
                                </p>
                                <span className={`text-[10px] ${
                                  selectedUser === contact.id ? 'text-white/70' : 'text-muted-foreground'
                                }`}>
                                  · {formatTime(latestMessage.created_at)}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">No contacts found</p>
                  </div>
                )}
              </ScrollArea>
            </div>
          )}
          
          {/* Conversation Area - Only show when on desktop or when in conversation view on mobile */}
          {(!isMobile || !showContactsList) && (
            <div className={`${isMobile ? 'col-span-1' : 'col-span-2'} flex flex-col h-full`}>
              {selectedUser ? (
                <>
                  <div className="border-b p-3 flex items-center bg-white sticky top-0">
                    {isMobile && (
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={handleBackToContacts}
                        className="mr-2"
                      >
                        <ChevronLeft className="h-5 w-5" />
                      </Button>
                    )}
                    <Avatar className="h-10 w-10 mr-3">
                      <AvatarImage 
                        src={selectedContact?.avatar_url || undefined} 
                        alt={selectedContact ? `${selectedContact.first_name} ${selectedContact.last_name}` : 'Contact'} 
                      />
                      <AvatarFallback>
                        {selectedContact?.first_name.charAt(0)}
                        {selectedContact?.last_name.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">
                        {selectedContact ? `${selectedContact.first_name} ${selectedContact.last_name}` : 'Contact'}
                      </p>
                      <p className="text-xs text-muted-foreground capitalize">
                        {selectedContact?.role || 'Unknown'}
                      </p>
                    </div>
                  </div>
                  
                  <ScrollArea className="flex-1 p-4">
                    <div className="space-y-4">
                      {messages.length > 0 ? (
                        messages.map(msg => {
                          const isSender = msg.senderId === user.id;
                          
                          return (
                            <div 
                              key={msg.id} 
                              className={`flex ${isSender ? 'justify-end' : 'justify-start'}`}
                            >
                              <div className={`max-w-[75%] rounded-lg p-3 ${
                                isSender 
                                  ? 'bg-primary text-white rounded-br-none' 
                                  : 'bg-muted rounded-bl-none'
                              }`}>
                                <p className="text-sm break-words">{msg.content}</p>
                                <p className={`text-[10px] text-right mt-1 ${
                                  isSender ? 'text-white/70' : 'text-muted-foreground'
                                }`}>
                                  {formatTime(msg.created_at)}
                                  {isSender && (
                                    <span className="ml-1">
                                      {msg.read ? '✓✓' : '✓'}
                                    </span>
                                  )}
                                </p>
                              </div>
                            </div>
                          );
                        })
                      ) : (
                        <div className="text-center py-10">
                          <p className="text-muted-foreground">
                            No messages yet. Start the conversation!
                          </p>
                        </div>
                      )}
                      <div ref={messagesEndRef} />
                    </div>
                  </ScrollArea>
                  
                  <div className="border-t p-3 bg-white sticky bottom-0">
                    <form 
                      className="flex items-center gap-2" 
                      onSubmit={(e) => {
                        e.preventDefault();
                        handleSendMessage();
                      }}
                    >
                      <Input 
                        placeholder="Type a message..." 
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        className="flex-1"
                      />
                      <Button 
                        type="submit"
                        disabled={!message.trim()}
                        size="icon"
                      >
                        <Send className="h-4 w-4" />
                      </Button>
                    </form>
                  </div>
                </>
              ) : (
                <div className="flex-1 flex items-center justify-center">
                  <div className="text-center">
                    <p className="text-muted-foreground mb-2">
                      Select a conversation to start messaging
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </Card>
    </div>
  );
};

export default Chat;
