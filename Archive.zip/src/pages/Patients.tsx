import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Plus, UserPlus } from 'lucide-react';
import { getPatients, getUsersByRole, getUserById, savePatient, saveUser, generateUUID, getDoctors, assignDoctorToPatient } from '@/services/localStorageService';
import { Patient, HealthcareUser, UserRole } from '@/types/healthcare';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { useForm } from 'react-hook-form';
import { Form, FormField, FormItem, FormLabel, FormControl } from '@/components/ui/form';
import { toast } from '@/components/ui/use-toast';

interface NewPatientFormData {
  firstName: string;
  lastName: string;
  email: string;
  gender: 'male' | 'female' | 'other';
  bloodType: string;
  dateOfBirth: string;
}

const Patients = () => {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [patients, setPatients] = useState<Patient[]>([]);
  const [patientUsers, setPatientUsers] = useState<HealthcareUser[]>([]);
  const [addPatientDialogOpen, setAddPatientDialogOpen] = useState(false);
  const [viewPatient, setViewPatient] = useState<Patient | null>(null);
  const [assignDoctorDialogOpen, setAssignDoctorDialogOpen] = useState(false);
  const [selectedPatientForDoctor, setSelectedPatientForDoctor] = useState<Patient | null>(null);
  const [selectedDoctorId, setSelectedDoctorId] = useState('');
  const [doctors, setDoctors] = useState<HealthcareUser[]>([]);

  const addPatientForm = useForm<NewPatientFormData>({
    defaultValues: {
      firstName: '',
      lastName: '',
      email: '',
      gender: 'male',
      bloodType: 'O+',
      dateOfBirth: '',
    }
  });
  
  useEffect(() => {
    setPatients(getPatients());
    setPatientUsers(getUsersByRole('patient'));
    setDoctors(getUsersByRole('doctor'));
  }, []);

  // Add new patient logic
  const handleAddNewPatient = (data: NewPatientFormData) => {
      // Check if email already exists
      const existingUsers = getUsersByRole('patient');
      const emailExists = existingUsers.some(u => u.email.toLowerCase() === data.email.toLowerCase());
      if (emailExists) {
      toast({ title: 'Error', description: 'A user with this email already exists', variant: 'destructive' });
        return;
      }
    // Create user and patient
      const userId = generateUUID();
      const authId = generateUUID();
      const newUser: HealthcareUser = {
        id: userId,
        auth_id: authId,
        email: data.email,
      password: 'password123',
        first_name: data.firstName,
        last_name: data.lastName,
        role: 'patient' as UserRole,
        avatar_url: null,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      const newPatient: Patient = {
        id: generateUUID(),
        userId: userId,
        dateOfBirth: data.dateOfBirth,
        gender: data.gender,
        bloodType: data.bloodType,
        height: 0,
        weight: 0,
        allergies: [],
        medicalConditions: [],
      emergencyContact: { name: '', relationship: '', contactNumber: '' },
        assignedDoctor: '',
        reportedSymptoms: [],
        created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      newForRoles: { admin: true, doctor: true, paramist: true }
      };
      saveUser(newUser);
      savePatient(newPatient);
    toast({ title: 'Patient Added', description: `${data.firstName} ${data.lastName} has been added as a patient` });
      addPatientForm.reset();
      setAddPatientDialogOpen(false);
    setPatients(getPatients());
    setPatientUsers(getUsersByRole('patient'));
  };

  // Register an existing user as a patient (create Patient profile)
  const handleRegisterPatient = (user: HealthcareUser) => {
    const newPatient: Patient = {
      id: generateUUID(),
      userId: user.id,
      dateOfBirth: '',
      gender: 'male',
      bloodType: 'O+',
      height: 0,
      weight: 0,
      allergies: [],
      medicalConditions: [],
      emergencyContact: { name: '', relationship: '', contactNumber: '' },
      assignedDoctor: '',
      reportedSymptoms: [],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      newForRoles: { admin: true, doctor: true, paramist: true }
    };
    savePatient(newPatient);
    toast({ title: 'Patient Registered', description: `${user.first_name} ${user.last_name} is now a patient.` });
    setPatients(getPatients());
  };

  // Filter logic
  const filteredPatientUsers = patientUsers.filter(u => {
    return searchQuery
      ? (u.first_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
         u.last_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
         u.email.toLowerCase().includes(searchQuery.toLowerCase()))
      : true;
  });

  // Find users without a Patient profile
  const usersWithoutPatientProfile = filteredPatientUsers.filter(u => !patients.some(p => p.userId === u.id));
  const usersWithPatientProfile = filteredPatientUsers.filter(u => patients.some(p => p.userId === u.id));
  
  // Assign doctor logic
  const handleOpenAssignDoctor = (patient: Patient) => {
    setSelectedPatientForDoctor(patient);
    setSelectedDoctorId(patient.assignedDoctor || '');
    setAssignDoctorDialogOpen(true);
  };

  const handleAssignDoctor = () => {
    if (!selectedPatientForDoctor || !selectedDoctorId) return;
    assignDoctorToPatient(selectedPatientForDoctor.id, selectedDoctorId);
    toast({ title: 'Doctor Assigned', description: 'Doctor has been assigned to the patient.' });
    setPatients(getPatients());
    setAssignDoctorDialogOpen(false);
    setSelectedPatientForDoctor(null);
    setSelectedDoctorId('');
  };

  return (
    <div className="w-full max-w-full overflow-x-hidden px-1 sm:px-0">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-4 gap-2">
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-1">Patients</h2>
          <p className="text-muted-foreground text-sm">Manage and view patient information</p>
        </div>
        {(user?.role === 'admin' || user?.role === 'receptionist') && (
          <Button className="w-full sm:w-auto" onClick={() => setAddPatientDialogOpen(true)}>
            <UserPlus className="mr-2 h-4 w-4" /> Add New Patient
          </Button>
        )}
      </div>
      <div className="mb-4">
              <Input
                placeholder="Search patients..."
          className="w-full max-w-md"
                value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
              />
            </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 w-full mb-8">
        {/* Users with Patient profile */}
        {usersWithPatientProfile.map(u => {
          const patient = patients.find(p => p.userId === u.id);
          return (
            <Card key={u.id} className="w-full max-w-full p-4 flex flex-col gap-2">
              <div className="flex flex-col gap-1">
                <span className="font-bold text-lg">{u.first_name} {u.last_name}</span>
                <span className="text-xs text-muted-foreground break-all">{u.email}</span>
          </div>
              <div className="flex flex-wrap gap-2 text-sm mt-2">
                <div><span className="font-medium">Gender:</span> {patient?.gender || '-'}</div>
                <div><span className="font-medium">Doctor:</span> {patient?.assignedDoctor ? getUserById(patient.assignedDoctor)?.first_name + ' ' + getUserById(patient.assignedDoctor)?.last_name : 'Not assigned'}</div>
                    </div>
              <div className="flex gap-2 mt-4">
                <Button variant="ghost" size="sm" className="flex-1" onClick={() => setViewPatient(patient || null)}>View</Button>
                {(user?.role === 'admin' || user?.role === 'receptionist') && (
                  <Button variant="outline" size="sm" className="flex-1" onClick={() => handleOpenAssignDoctor(patient!)}>Assign Doctor</Button>
                )}
              </div>
            </Card>
          );
        })}
        {/* Users without Patient profile */}
        {usersWithoutPatientProfile.map(u => (
          <Card key={u.id} className="w-full max-w-full p-4 flex flex-col gap-2 border-2 border-dashed border-yellow-400">
            <div className="flex flex-col gap-1">
              <span className="font-bold text-lg">{u.first_name} {u.last_name}</span>
              <span className="text-xs text-muted-foreground break-all">{u.email}</span>
            </div>
            <div className="flex flex-wrap gap-2 text-sm mt-2">
              <Badge variant="destructive">Not Registered</Badge>
            </div>
            <div className="flex gap-2 mt-4">
              <Button variant="outline" size="sm" className="flex-1" onClick={() => handleRegisterPatient(u)}>
                Register as Patient
              </Button>
                        </div>
          </Card>
                      ))}
                    </div>
      {/* Empty state if no patients or users */}
      {usersWithPatientProfile.length === 0 && usersWithoutPatientProfile.length === 0 && (
        <div className="flex flex-col items-center justify-center py-12">
          <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
            <UserPlus className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <h3 className="font-medium mb-1">No patients found</h3>
          <p className="text-muted-foreground text-sm mb-4">There are no patients in the system.</p>
                  {(user?.role === 'admin' || user?.role === 'receptionist') && (
                    <Button onClick={() => setAddPatientDialogOpen(true)}>
                      <Plus className="mr-2 h-4 w-4" /> Add New Patient
                    </Button>
                  )}
                </div>
              )}
      {/* Add New Patient Dialog */}
      <Dialog open={addPatientDialogOpen} onOpenChange={setAddPatientDialogOpen}>
        <DialogContent className="sm:max-w-[500px] w-full max-w-full p-2 md:p-6">
          <DialogHeader>
            <DialogTitle>Add New Patient</DialogTitle>
            <DialogDescription>Enter patient information to create a new patient account</DialogDescription>
          </DialogHeader>
          <Form {...addPatientForm}>
            <form onSubmit={addPatientForm.handleSubmit(handleAddNewPatient)} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField control={addPatientForm.control} name="firstName" render={({ field }) => (
                    <FormItem>
                      <FormLabel>First Name</FormLabel>
                      <FormControl>
                        <Input placeholder="First name" {...field} required />
                      </FormControl>
                    </FormItem>
                )} />
                <FormField control={addPatientForm.control} name="lastName" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Last Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Last name" {...field} required />
                      </FormControl>
                    </FormItem>
                )} />
              </div>
              <FormField control={addPatientForm.control} name="email" render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="patient@example.com" {...field} required />
                  </FormControl>
                </FormItem>
              )} />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField control={addPatientForm.control} name="gender" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Gender</FormLabel>
                    <FormControl>
                      <select {...field} className="w-full border rounded p-2">
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                      </select>
                    </FormControl>
                  </FormItem>
                )} />
                <FormField control={addPatientForm.control} name="bloodType" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Blood Type</FormLabel>
                        <FormControl>
                      <select {...field} className="w-full border rounded p-2">
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                      </select>
                        </FormControl>
                    </FormItem>
                )} />
              </div>
              <FormField control={addPatientForm.control} name="dateOfBirth" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date of Birth</FormLabel>
                    <FormControl>
                    <Input type="date" {...field} required />
                    </FormControl>
                  </FormItem>
              )} />
              <DialogFooter>
                <Button variant="outline" type="button" onClick={() => setAddPatientDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  <Plus className="mr-2 h-4 w-4" /> Add Patient
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      {/* Patient Details Modal */}
      <Dialog open={!!viewPatient} onOpenChange={() => setViewPatient(null)}>
        <DialogContent className="sm:max-w-[500px] w-full max-w-full p-2 md:p-6">
          <DialogHeader>
            <DialogTitle>Patient Details</DialogTitle>
          </DialogHeader>
          {viewPatient && (
            <div className="space-y-2">
              <div><b>Name:</b> {getUserById(viewPatient.userId)?.first_name} {getUserById(viewPatient.userId)?.last_name}</div>
              <div><b>Email:</b> {getUserById(viewPatient.userId)?.email}</div>
              <div><b>Gender:</b> {viewPatient.gender}</div>
              <div><b>Blood Type:</b> {viewPatient.bloodType}</div>
              <div><b>Date of Birth:</b> {viewPatient.dateOfBirth}</div>
              <div><b>Doctor:</b> {viewPatient.assignedDoctor ? getUserById(viewPatient.assignedDoctor)?.first_name + ' ' + getUserById(viewPatient.assignedDoctor)?.last_name : 'Not assigned'}</div>
              <div><b>Allergies:</b> {viewPatient.allergies.length > 0 ? viewPatient.allergies.join(', ') : 'None'}</div>
              <div><b>Medical Conditions:</b> {viewPatient.medicalConditions.length > 0 ? viewPatient.medicalConditions.join(', ') : 'None'}</div>
              <div><b>Emergency Contact:</b> {viewPatient.emergencyContact?.name || '-'} ({viewPatient.emergencyContact?.relationship || '-'}) {viewPatient.emergencyContact?.contactNumber || ''}</div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setViewPatient(null)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {/* Assign Doctor Dialog */}
      <Dialog open={assignDoctorDialogOpen} onOpenChange={setAssignDoctorDialogOpen}>
        <DialogContent className="sm:max-w-[400px] w-full">
          <DialogHeader>
            <DialogTitle>Assign Doctor</DialogTitle>
            <DialogDescription>Select a doctor to assign to this patient.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <select
              className="w-full border rounded p-2"
              value={selectedDoctorId}
              onChange={e => setSelectedDoctorId(e.target.value)}
            >
              <option value="">Select doctor</option>
              {doctors.map(doc => (
                <option key={doc.id} value={doc.id}>
                  {doc.first_name} {doc.last_name} ({doc.email})
                </option>
              ))}
            </select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAssignDoctorDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleAssignDoctor} disabled={!selectedDoctorId}>Assign</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Patients;
