
import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/components/ui/use-toast';
import { useIsMobile } from '@/hooks/use-mobile';

const Settings = () => {
  const { user } = useAuth();
  const isMobile = useIsMobile();
  
  // Profile settings
  const [profile, setProfile] = useState({
    firstName: user?.first_name || '',
    lastName: user?.last_name || '',
    email: user?.email || '',
    phone: '',
    // Professional info for doctors
    specialization: '',
    license: '',
    education: '',
    experience: '',
    // Medical info for patients
    dob: '',
    gender: 'male',
    bloodType: '',
    allergies: '',
    conditions: '',
  });

  // Account preferences
  const [preferences, setPreferences] = useState({
    theme: 'light',
    language: 'en',
    timezone: 'utc',
  });

  // Notification settings
  const [notifications, setNotifications] = useState({
    email: {
      appointments: true,
      messages: true,
      prescriptions: true,
      records: true,
    },
    sms: {
      appointments: true,
      prescriptions: false,
    },
    app: {
      all: true,
      sound: false,
    }
  });

  // Security settings
  const [security, setSecurity] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
    twoFactor: false,
    dataSharingConsent: false,
    analyticsConsent: true,
    marketingConsent: false,
  });

  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Profile Updated",
      description: "Your profile information has been updated successfully."
    });
  };

  const handlePreferencesSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Preferences Saved",
      description: "Your account preferences have been updated."
    });
  };

  const handleNotificationsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Notification Settings Updated",
      description: "Your notification preferences have been saved."
    });
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (security.newPassword !== security.confirmPassword) {
      toast({
        title: "Passwords Don't Match",
        description: "Your new password and confirmation don't match.",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: "Password Updated",
      description: "Your password has been changed successfully."
    });
    
    setSecurity({
      ...security,
      currentPassword: '',
      newPassword: '',
      confirmPassword: '',
    });
  };

  const handlePrivacySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Privacy Settings Updated",
      description: "Your privacy settings have been saved."
    });
  };

  if (!user) return null;

  return (
    <div className="fade-in">
      <div className="mb-6">
        <h2 className="text-3xl font-bold tracking-tight mb-2">Settings</h2>
        <p className="text-muted-foreground">Manage your account and preferences</p>
      </div>

      <Tabs defaultValue="profile" className="space-y-4">
        <TabsList className={isMobile ? "w-full" : ""}>
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="account">Account</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>
        
        <TabsContent value="profile">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <form onSubmit={handleProfileSubmit}>
                <CardHeader>
                  <CardTitle>Personal Information</CardTitle>
                  <CardDescription>
                    Update your personal details and contact information
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <Avatar className="h-24 w-24">
                      <AvatarImage src={user.avatar_url || undefined} alt={`${user.first_name} ${user.last_name}`} />
                      <AvatarFallback className="text-2xl">
                        {user.first_name.charAt(0)}
                        {user.last_name.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <Button variant="outline" size="sm" className="mb-2">
                        Change Avatar
                      </Button>
                      <p className="text-xs text-muted-foreground">
                        JPG, GIF or PNG. 1MB max.
                      </p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First name</Label>
                      <Input 
                        id="firstName" 
                        value={profile.firstName}
                        onChange={(e) => setProfile({...profile, firstName: e.target.value})} 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last name</Label>
                      <Input 
                        id="lastName" 
                        value={profile.lastName}
                        onChange={(e) => setProfile({...profile, lastName: e.target.value})} 
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input 
                      id="email" 
                      value={profile.email}
                      onChange={(e) => setProfile({...profile, email: e.target.value})} 
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone number</Label>
                    <Input 
                      id="phone" 
                      placeholder="Enter your phone number"
                      value={profile.phone}
                      onChange={(e) => setProfile({...profile, phone: e.target.value})} 
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="role">Role</Label>
                    <div className="flex items-center gap-2">
                      <Badge className="capitalize">{user.role}</Badge>
                      <span className="text-xs text-muted-foreground">
                        (Contact administrator for role changes)
                      </span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button type="submit">Save Changes</Button>
                </CardFooter>
              </form>
            </Card>
            
            {user.role === 'doctor' && (
              <Card>
                <form onSubmit={handleProfileSubmit}>
                  <CardHeader>
                    <CardTitle>Professional Information</CardTitle>
                    <CardDescription>
                      Update your medical specialization and credentials
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="specialization">Specialization</Label>
                      <Input 
                        id="specialization" 
                        placeholder="e.g., Cardiology, Pediatrics"
                        value={profile.specialization}
                        onChange={(e) => setProfile({...profile, specialization: e.target.value})}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="license">License Number</Label>
                      <Input 
                        id="license" 
                        placeholder="Enter your medical license number"
                        value={profile.license}
                        onChange={(e) => setProfile({...profile, license: e.target.value})}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="education">Education</Label>
                      <Textarea 
                        id="education" 
                        placeholder="List your educational background" 
                        className="min-h-[120px]"
                        value={profile.education}
                        onChange={(e) => setProfile({...profile, education: e.target.value})}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="experience">Years of Experience</Label>
                      <Input 
                        id="experience" 
                        type="number" 
                        min="0" 
                        placeholder="0"
                        value={profile.experience}
                        onChange={(e) => setProfile({...profile, experience: e.target.value})}
                      />
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button type="submit">Save Changes</Button>
                  </CardFooter>
                </form>
              </Card>
            )}
            
            {user.role === 'patient' && (
              <Card>
                <form onSubmit={handleProfileSubmit}>
                  <CardHeader>
                    <CardTitle>Medical Information</CardTitle>
                    <CardDescription>
                      Update your personal health information
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="dob">Date of Birth</Label>
                      <Input 
                        id="dob" 
                        type="date"
                        value={profile.dob}
                        onChange={(e) => setProfile({...profile, dob: e.target.value})}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="gender">Gender</Label>
                      <select 
                        id="gender" 
                        className="w-full p-2 rounded-md border border-input bg-background"
                        value={profile.gender}
                        onChange={(e) => setProfile({...profile, gender: e.target.value})}
                      >
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="bloodType">Blood Type</Label>
                      <select 
                        id="bloodType" 
                        className="w-full p-2 rounded-md border border-input bg-background"
                        value={profile.bloodType}
                        onChange={(e) => setProfile({...profile, bloodType: e.target.value})}
                      >
                        <option value="">Unknown</option>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                      </select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="allergies">Allergies</Label>
                      <Textarea 
                        id="allergies" 
                        placeholder="List any allergies (separated by commas)"
                        value={profile.allergies}
                        onChange={(e) => setProfile({...profile, allergies: e.target.value})}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="conditions">Medical Conditions</Label>
                      <Textarea 
                        id="conditions" 
                        placeholder="List any chronic medical conditions (separated by commas)"
                        value={profile.conditions}
                        onChange={(e) => setProfile({...profile, conditions: e.target.value})}
                      />
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button type="submit">Save Changes</Button>
                  </CardFooter>
                </form>
              </Card>
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="account">
          <Card>
            <form onSubmit={handlePreferencesSubmit}>
              <CardHeader>
                <CardTitle>Account Preferences</CardTitle>
                <CardDescription>
                  Manage your account settings and preferences
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="theme" className="block mb-1">Light/Dark Mode</Label>
                      <p className="text-sm text-muted-foreground">Adjust the appearance of the application.</p>
                    </div>
                    <select 
                      id="theme" 
                      className="p-2 rounded-md border border-input bg-background"
                      value={preferences.theme}
                      onChange={(e) => setPreferences({...preferences, theme: e.target.value})}
                    >
                      <option value="light">Light</option>
                      <option value="dark">Dark</option>
                      <option value="system">System Default</option>
                    </select>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="language" className="block mb-1">Language</Label>
                      <p className="text-sm text-muted-foreground">Select your preferred language.</p>
                    </div>
                    <select 
                      id="language" 
                      className="p-2 rounded-md border border-input bg-background"
                      value={preferences.language}
                      onChange={(e) => setPreferences({...preferences, language: e.target.value})}
                    >
                      <option value="en">English</option>
                      <option value="es">Español</option>
                      <option value="fr">Français</option>
                    </select>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="timezone" className="block mb-1">Timezone</Label>
                      <p className="text-sm text-muted-foreground">Select your local timezone.</p>
                    </div>
                    <select 
                      id="timezone" 
                      className="p-2 rounded-md border border-input bg-background"
                      value={preferences.timezone}
                      onChange={(e) => setPreferences({...preferences, timezone: e.target.value})}
                    >
                      <option value="utc">UTC (Coordinated Universal Time)</option>
                      <option value="est">Eastern Standard Time (EST)</option>
                      <option value="cst">Central Standard Time (CST)</option>
                      <option value="pst">Pacific Standard Time (PST)</option>
                    </select>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button type="submit">Save Preferences</Button>
              </CardFooter>
            </form>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifications">
          <Card>
            <form onSubmit={handleNotificationsSubmit}>
              <CardHeader>
                <CardTitle>Notification Preferences</CardTitle>
                <CardDescription>
                  Configure how you receive notifications
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-4 border-b">
                    <div>
                      <Label className="text-base">Email Notifications</Label>
                      <p className="text-sm text-muted-foreground">Configure email notification settings</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="email-appointments" className="flex-1">Appointment Reminders</Label>
                      <Switch 
                        id="email-appointments" 
                        checked={notifications.email.appointments}
                        onCheckedChange={(checked) => setNotifications({
                          ...notifications,
                          email: {...notifications.email, appointments: checked}
                        })}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="email-messages" className="flex-1">New Messages</Label>
                      <Switch 
                        id="email-messages" 
                        checked={notifications.email.messages}
                        onCheckedChange={(checked) => setNotifications({
                          ...notifications,
                          email: {...notifications.email, messages: checked}
                        })}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="email-prescriptions" className="flex-1">Prescription Updates</Label>
                      <Switch 
                        id="email-prescriptions" 
                        checked={notifications.email.prescriptions}
                        onCheckedChange={(checked) => setNotifications({
                          ...notifications,
                          email: {...notifications.email, prescriptions: checked}
                        })}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="email-records" className="flex-1">Medical Record Updates</Label>
                      <Switch 
                        id="email-records" 
                        checked={notifications.email.records}
                        onCheckedChange={(checked) => setNotifications({
                          ...notifications,
                          email: {...notifications.email, records: checked}
                        })}
                      />
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between pb-4 border-b border-t pt-4">
                    <div>
                      <Label className="text-base">SMS Notifications</Label>
                      <p className="text-sm text-muted-foreground">Configure text message notifications</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="sms-appointments" className="flex-1">Appointment Reminders</Label>
                      <Switch 
                        id="sms-appointments" 
                        checked={notifications.sms.appointments}
                        onCheckedChange={(checked) => setNotifications({
                          ...notifications,
                          sms: {...notifications.sms, appointments: checked}
                        })}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="sms-prescriptions" className="flex-1">Prescription Ready</Label>
                      <Switch 
                        id="sms-prescriptions" 
                        checked={notifications.sms.prescriptions}
                        onCheckedChange={(checked) => setNotifications({
                          ...notifications,
                          sms: {...notifications.sms, prescriptions: checked}
                        })}
                      />
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between pb-4 border-b border-t pt-4">
                    <div>
                      <Label className="text-base">System Notifications</Label>
                      <p className="text-sm text-muted-foreground">Configure in-app notifications</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="in-app-all" className="flex-1">All Notifications</Label>
                      <Switch 
                        id="in-app-all" 
                        checked={notifications.app.all}
                        onCheckedChange={(checked) => setNotifications({
                          ...notifications,
                          app: {...notifications.app, all: checked}
                        })}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="in-app-sound" className="flex-1">Notification Sounds</Label>
                      <Switch 
                        id="in-app-sound" 
                        checked={notifications.app.sound}
                        onCheckedChange={(checked) => setNotifications({
                          ...notifications,
                          app: {...notifications.app, sound: checked}
                        })}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button type="submit">Save Notification Preferences</Button>
              </CardFooter>
            </form>
          </Card>
        </TabsContent>
        
        <TabsContent value="security">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <form onSubmit={handlePasswordSubmit}>
                <CardHeader>
                  <CardTitle>Change Password</CardTitle>
                  <CardDescription>
                    Update your account password
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="current-password">Current Password</Label>
                    <Input 
                      id="current-password" 
                      type="password"
                      value={security.currentPassword}
                      onChange={(e) => setSecurity({...security, currentPassword: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="new-password">New Password</Label>
                    <Input 
                      id="new-password" 
                      type="password"
                      value={security.newPassword}
                      onChange={(e) => setSecurity({...security, newPassword: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">Confirm New Password</Label>
                    <Input 
                      id="confirm-password" 
                      type="password"
                      value={security.confirmPassword}
                      onChange={(e) => setSecurity({...security, confirmPassword: e.target.value})}
                    />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button type="submit">Update Password</Button>
                </CardFooter>
              </form>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Two-Factor Authentication</CardTitle>
                <CardDescription>
                  Add additional security to your account
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="2fa" className="block mb-1">Enable 2FA</Label>
                    <p className="text-sm text-muted-foreground">Protect your account with two-factor authentication.</p>
                  </div>
                  <Switch 
                    id="2fa" 
                    checked={security.twoFactor}
                    onCheckedChange={(checked) => setSecurity({...security, twoFactor: checked})}
                  />
                </div>
                
                <div className="rounded-md bg-muted p-4">
                  <p className="text-sm font-medium">Two-factor authentication is currently {security.twoFactor ? 'enabled' : 'disabled'}</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {security.twoFactor 
                      ? 'Your account is protected with two-factor authentication.' 
                      : 'Enable two-factor authentication for enhanced security. You\'ll need an authenticator app like Google Authenticator or Authy.'}
                  </p>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="mt-2"
                    onClick={() => {
                      if (!security.twoFactor) {
                        // In real app this would launch setup flow
                        setSecurity({...security, twoFactor: true});
                        toast({
                          title: "2FA Enabled",
                          description: "Two-factor authentication has been enabled for your account."
                        });
                      } else {
                        setSecurity({...security, twoFactor: false});
                        toast({
                          title: "2FA Disabled",
                          description: "Two-factor authentication has been disabled for your account."
                        });
                      }
                    }}
                  >
                    {security.twoFactor ? 'Disable 2FA' : 'Set up 2FA'}
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Session Management</CardTitle>
                <CardDescription>
                  Manage your active sessions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="border rounded-md p-3">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <p className="font-medium">Current Session</p>
                        <p className="text-sm text-muted-foreground">Chrome on Windows • IP: 192.168.1.1</p>
                      </div>
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Active</Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">Started: May 3, 2025 at 10:23 AM</p>
                  </div>
                  
                  <div className="border rounded-md p-3">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <p className="font-medium">Mobile App</p>
                        <p className="text-sm text-muted-foreground">iPhone • IP: 192.168.1.5</p>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-7 text-destructive"
                        onClick={() => {
                          toast({
                            title: "Session Terminated",
                            description: "Mobile session has been terminated successfully."
                          });
                        }}
                      >
                        Terminate
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">Started: May 2, 2025 at 3:45 PM</p>
                  </div>
                </div>
                
                <Button 
                  variant="outline" 
                  className="w-full mt-4"
                  onClick={() => {
                    toast({
                      title: "All Sessions Terminated",
                      description: "You've been logged out from all devices."
                    });
                  }}
                >
                  Logout from all devices
                </Button>
              </CardContent>
            </Card>
            
            <Card>
              <form onSubmit={handlePrivacySubmit}>
                <CardHeader>
                  <CardTitle>Privacy Settings</CardTitle>
                  <CardDescription>
                    Manage how your information is handled
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="data-sharing" className="block mb-1">Data Sharing</Label>
                        <p className="text-sm text-muted-foreground">Allow sharing of anonymized health data for research</p>
                      </div>
                      <Switch 
                        id="data-sharing" 
                        checked={security.dataSharingConsent}
                        onCheckedChange={(checked) => setSecurity({...security, dataSharingConsent: checked})}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="analytics" className="block mb-1">Usage Analytics</Label>
                        <p className="text-sm text-muted-foreground">Allow collection of app usage data</p>
                      </div>
                      <Switch 
                        id="analytics" 
                        checked={security.analyticsConsent}
                        onCheckedChange={(checked) => setSecurity({...security, analyticsConsent: checked})}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="marketing" className="block mb-1">Marketing Communications</Label>
                        <p className="text-sm text-muted-foreground">Receive promotional emails and updates</p>
                      </div>
                      <Switch 
                        id="marketing" 
                        checked={security.marketingConsent}
                        onCheckedChange={(checked) => setSecurity({...security, marketingConsent: checked})}
                      />
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button type="submit">Save Privacy Settings</Button>
                </CardFooter>
              </form>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Settings;
