import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Pill, Check, Clock, AlertCircle, Plus, Search, X, PlusCircle, Trash2 } from 'lucide-react';

import {
  getPrescriptionsByDoctorId,
  getPrescriptionsByPatientId,
  getPrescriptions,
  savePrescription,
  getUserById,
  getUsersByRole,
  getPatientByUserId,
  getMedications,
  generateUUID
} from '@/services/localStorageService';
import { Prescription, Medication } from '@/types/healthcare';

const PrescriptionsPage = () => {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([]);
  const [activeTab, setActiveTab] = useState('all');
  const { toast } = useToast();
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  
  // Prescription creation form state
  const [selectedPatient, setSelectedPatient] = useState<string>('');
  const [diagnosis, setDiagnosis] = useState<string>('');
  const [instructions, setInstructions] = useState<string>('');
  const [medications, setMedications] = useState<{
    medicationId: string;
    medicationName: string;
    dosage: string;
    frequency: string;
    duration: string;
    notes: string;
  }[]>([]);
  
  // State for data lists
  const [patients, setPatients] = useState<{id: string; name: string}[]>([]);
  const [availableMedications, setAvailableMedications] = useState<Medication[]>([]);

  useEffect(() => {
    if (!user) return;
    
    // Load prescriptions based on user role
    loadPrescriptions();
    
    // Load patients list for doctors and admins
    if (user.role === 'doctor' || user.role === 'admin') {
      loadPatients();
    }
    
    // Load medications list
    loadMedications();
  }, [user]);

  const loadPrescriptions = () => {
    if (!user) return;
    
    let userPrescriptions: Prescription[] = [];
    
    if (user.role === 'doctor') {
      userPrescriptions = getPrescriptionsByDoctorId(user.id);
    } else if (user.role === 'patient') {
      userPrescriptions = getPrescriptionsByPatientId(user.id);
    } else if (user.role === 'pharmacist') {
      userPrescriptions = getPrescriptions();
    } else {
      // Admin can see all prescriptions
      userPrescriptions = getPrescriptions();
    }
    
    setPrescriptions(userPrescriptions);
  };

  const loadPatients = () => {
    const patientUsers = getUsersByRole('patient');
    setPatients(patientUsers.map(p => ({
      id: p.id,
      name: `${p.first_name} ${p.last_name}`
    })));
  };

  const loadMedications = () => {
    const medicationsList = getMedications();
    setAvailableMedications(medicationsList);
  };

  // Filter prescriptions based on search query and active tab
  const filteredPrescriptions = prescriptions
    .filter(prescription => {
      if (searchQuery) {
        const doctorName = getUserById(prescription.doctorId)?.last_name?.toLowerCase() || '';
        const patientName = getUserById(prescription.patientId)?.last_name?.toLowerCase() || '';
        const searchLower = searchQuery.toLowerCase();
        const medicationsMatch = prescription.medications.some(med => 
          med.medicationName.toLowerCase().includes(searchLower)
        );
        
        return doctorName.includes(searchLower) || 
               patientName.includes(searchLower) || 
               prescription.diagnosis.toLowerCase().includes(searchLower) ||
               medicationsMatch;
      }
      return true;
    })
    .filter(prescription => {
      if (activeTab === 'all') return true;
      return prescription.status === activeTab;
    });

  const handleAddMedication = () => {
    const newMedication = {
      medicationId: '',
      medicationName: '',
      dosage: '',
      frequency: '',
      duration: '',
      notes: ''
    };
    setMedications([...medications, newMedication]);
  };

  const handleRemoveMedication = (index: number) => {
    setMedications(medications.filter((_, i) => i !== index));
  };

  const handleMedicationChange = (index: number, field: keyof typeof medications[0], value: string) => {
    const updatedMedications = [...medications];
    updatedMedications[index] = { ...updatedMedications[index], [field]: value };
    
    // If changing the medication ID, also update the name
    if (field === 'medicationId' && value) {
      const selectedMedication = availableMedications.find(m => m.id === value);
      if (selectedMedication) {
        updatedMedications[index].medicationName = selectedMedication.name;
      }
    }
    
    setMedications(updatedMedications);
  };

  const handleCreatePrescription = () => {
    if (!user || user.role !== 'doctor') return;
    
    const newPrescription: Prescription = {
      id: generateUUID(),
      patientId: selectedPatient,
      doctorId: user.id,
      date: new Date().toISOString().split('T')[0],
      diagnosis,
      medications,
      instructions,
      status: 'created',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    try {
      savePrescription(newPrescription);
      toast({
        title: "Success",
        description: "Prescription created successfully",
      });
      setIsCreateModalOpen(false);
      resetPrescriptionForm();
      loadPrescriptions();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create prescription",
        variant: "destructive",
      });
    }
  };

  const handleUpdatePrescriptionStatus = (prescriptionId: string, status: 'created' | 'sent' | 'filled' | 'completed') => {
    const prescriptionToUpdate = prescriptions.find(p => p.id === prescriptionId);
    if (!prescriptionToUpdate) return;
    
    const updatedPrescription = {
      ...prescriptionToUpdate,
      status,
      updated_at: new Date().toISOString()
    };
    
    try {
      savePrescription(updatedPrescription);
      toast({
        title: "Success",
        description: `Prescription ${status} successfully`,
      });
      loadPrescriptions();
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to update prescription status`,
        variant: "destructive",
      });
    }
  };

  const resetPrescriptionForm = () => {
    setSelectedPatient('');
    setDiagnosis('');
    setInstructions('');
    setMedications([]);
  };

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'created':
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Created</Badge>;
      case 'sent':
        return <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">Sent</Badge>;
      case 'filled':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Filled</Badge>;
      case 'completed':
        return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">Completed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'created':
        return <Clock className="h-4 w-4 text-blue-500" />;
      case 'sent':
        return <AlertCircle className="h-4 w-4 text-amber-500" />;
      case 'filled':
        return <Check className="h-4 w-4 text-green-500" />;
      case 'completed':
        return <Check className="h-4 w-4 text-gray-500" />;
      default:
        return null;
    }
  };

  if (!user) return null;

  const isPatient = user.role === 'patient';
  const isDoctor = user.role === 'doctor';
  const isPharmacist = user.role === 'pharmacist';
  const isAdmin = user.role === 'admin';

  return (
    <div className="fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start mb-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight mb-2">Prescriptions</h2>
          <p className="text-muted-foreground">View and manage medication prescriptions</p>
        </div>
        
        {isDoctor && (
          <Button 
            className="mt-4 md:mt-0"
            onClick={() => setIsCreateModalOpen(true)}
          >
            <Plus className="mr-2 h-4 w-4" /> New Prescription
          </Button>
        )}
      </div>

      <Card className="w-full border rounded-md shadow-sm">
        <CardHeader className="flex flex-col gap-2 items-start justify-between">
          <div>
            <CardTitle>Prescription History</CardTitle>
            <CardDescription>View and manage your prescription records</CardDescription>
          </div>
          <div className="w-full flex flex-col gap-2">
            <div className="relative w-full">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search prescriptions..."
                className="w-full pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Tabs defaultValue="all" onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid grid-cols-4 w-full">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="sent">Pending</TabsTrigger>
                <TabsTrigger value="filled">Filled</TabsTrigger>
                <TabsTrigger value="completed">Complete</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardHeader>
        <CardContent>
          {filteredPrescriptions.length > 0 ? (
            <div className="flex flex-col gap-4 w-full">
              {filteredPrescriptions.map(prescription => {
                const doctorUser = getUserById(prescription.doctorId);
                const patientUser = getUserById(prescription.patientId);
                const doctorName = doctorUser ? `Dr. ${doctorUser.first_name} ${doctorUser.last_name}` : 'Unknown Doctor';
                const patientName = patientUser ? `${patientUser.first_name} ${patientUser.last_name}` : 'Unknown Patient';
                return (
                  <div key={prescription.id} className="w-full border rounded-md bg-white flex flex-col p-4 gap-2">
                    <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                      <div className="flex items-start gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">
                          <Pill className="h-5 w-5" />
                        </div>
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <h3 className="font-medium text-base">
                              Prescription for {isPatient ? 'You' : patientName}
                            </h3>
                            {getStatusBadge(prescription.status)}
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            {formatDate(prescription.date)} • Prescribed by {doctorName}
                          </p>
                          <div className="mt-1 text-xs">
                            <span className="font-medium">Diagnosis:</span> {prescription.diagnosis}
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2 mt-2 sm:mt-0">
                        <Button variant="outline" size="sm">View Details</Button>
                        {isPharmacist && prescription.status === 'sent' && (
                          <Button size="sm" onClick={() => handleUpdatePrescriptionStatus(prescription.id, 'filled')}>
                            Fill Prescription
                          </Button>
                        )}
                        {isDoctor && prescription.status === 'created' && (
                          <Button size="sm" onClick={() => handleUpdatePrescriptionStatus(prescription.id, 'sent')}>
                            Send to Pharmacy
                          </Button>
                        )}
                        {isPatient && prescription.status === 'filled' && (
                          <Button size="sm" onClick={() => handleUpdatePrescriptionStatus(prescription.id, 'completed')}>
                            Mark as Received
                          </Button>
                        )}
                      </div>
                    </div>
                    <div className="bg-muted/20 border-t p-3 mt-2 rounded-b-md">
                      <h4 className="text-xs font-semibold mb-1">Medications</h4>
                      <div className="flex flex-col gap-1">
                        {prescription.medications.map((medication, index) => (
                          <div key={index} className="flex items-start gap-2">
                            <div className="h-2 w-2 rounded-full bg-primary mt-2"></div>
                            <div>
                              <div className="text-xs font-medium">
                                {medication.medicationName} {medication.dosage}
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {medication.frequency} for {medication.duration}
                                {medication.notes && ` • ${medication.notes}`}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                      {prescription.instructions && (
                        <div className="mt-2 pt-2 border-t text-xs">
                          <span className="font-medium">Instructions:</span> {prescription.instructions}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-10 border rounded-md bg-muted/5">
              <Pill className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
              <h3 className="font-medium mb-1">No Prescriptions Found</h3>
              <p className="text-muted-foreground text-sm mb-4">
                {searchQuery 
                  ? "No prescriptions match your search criteria." 
                  : "You don't have any prescriptions yet. Prescriptions will appear here once they are created."}
              </p>
              {isDoctor && (
                <Button onClick={() => setIsCreateModalOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" /> Create New Prescription
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create Prescription Modal */}
      <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
        <DialogContent className="sm:max-w-[500px] w-full max-w-full max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create New Prescription</DialogTitle>
            <DialogDescription>
              Fill out the prescription details for your patient.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="patient">Patient</Label>
              <Select
                value={selectedPatient}
                onValueChange={setSelectedPatient}
              >
                <SelectTrigger id="patient">
                  <SelectValue placeholder="Select patient" />
                </SelectTrigger>
                <SelectContent>
                  {patients.map(patient => (
                    <SelectItem key={patient.id} value={patient.id}>
                      {patient.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="diagnosis">Diagnosis</Label>
              <Input
                id="diagnosis"
                placeholder="Enter diagnosis"
                value={diagnosis}
                onChange={(e) => setDiagnosis(e.target.value)}
              />
            </div>
            
            <div className="grid gap-2">
              <div className="flex items-center justify-between">
                <Label>Medications</Label>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-8 gap-1" 
                  onClick={handleAddMedication}
                >
                  <PlusCircle className="h-4 w-4" />
                  Add Medication
                </Button>
              </div>
              
              <div className="space-y-4">
                {medications.map((medication, index) => (
                  <div key={index} className="border rounded-md p-3 relative">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute top-1 right-1 h-6 w-6"
                      onClick={() => handleRemoveMedication(index)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                    
                    <div className="grid gap-3">
                      <div className="grid gap-2">
                        <Label htmlFor={`medication-${index}`}>Medication</Label>
                        <Select
                          value={medication.medicationId}
                          onValueChange={(value) => handleMedicationChange(index, 'medicationId', value)}
                        >
                          <SelectTrigger id={`medication-${index}`}>
                            <SelectValue placeholder="Select medication" />
                          </SelectTrigger>
                          <SelectContent>
                            {availableMedications.map(med => (
                              <SelectItem key={med.id} value={med.id}>
                                {med.name} ({med.strength} {med.dosageForm})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-3">
                        <div className="grid gap-2">
                          <Label htmlFor={`dosage-${index}`}>Dosage</Label>
                          <Input
                            id={`dosage-${index}`}
                            placeholder="e.g., 10mg"
                            value={medication.dosage}
                            onChange={(e) => handleMedicationChange(index, 'dosage', e.target.value)}
                          />
                        </div>
                        
                        <div className="grid gap-2">
                          <Label htmlFor={`frequency-${index}`}>Frequency</Label>
                          <Input
                            id={`frequency-${index}`}
                            placeholder="e.g., Twice daily"
                            value={medication.frequency}
                            onChange={(e) => handleMedicationChange(index, 'frequency', e.target.value)}
                          />
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-3">
                        <div className="grid gap-2">
                          <Label htmlFor={`duration-${index}`}>Duration</Label>
                          <Input
                            id={`duration-${index}`}
                            placeholder="e.g., 10 days"
                            value={medication.duration}
                            onChange={(e) => handleMedicationChange(index, 'duration', e.target.value)}
                          />
                        </div>
                        
                        <div className="grid gap-2">
                          <Label htmlFor={`notes-${index}`}>Notes (Optional)</Label>
                          <Input
                            id={`notes-${index}`}
                            placeholder="Additional instructions"
                            value={medication.notes}
                            onChange={(e) => handleMedicationChange(index, 'notes', e.target.value)}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                
                {medications.length === 0 && (
                  <div className="text-center py-4 border rounded-md border-dashed">
                    <p className="text-sm text-muted-foreground">No medications added</p>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="mt-2" 
                      onClick={handleAddMedication}
                    >
                      <PlusCircle className="h-4 w-4 mr-2" />
                      Add Medication
                    </Button>
                  </div>
                )}
              </div>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="instructions">Instructions (Optional)</Label>
              <Textarea
                id="instructions"
                placeholder="Enter additional instructions"
                value={instructions}
                onChange={(e) => setInstructions(e.target.value)}
                rows={3}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateModalOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleCreatePrescription}
              disabled={
                !selectedPatient || 
                !diagnosis || 
                medications.length === 0 ||
                medications.some(m => !m.medicationId || !m.dosage || !m.frequency || !m.duration)
              }
            >
              Create Prescription
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PrescriptionsPage;
