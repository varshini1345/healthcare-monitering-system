import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Calendar, 
  Clock, 
  User, 
  Activity, 
  FileText,
  Bell
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { DashboardData, Appointment, HealthcareUser, Activity as ActivityType } from '@/types/healthcare';
import { useNavigate } from 'react-router-dom';
import { toast } from '@/components/ui/use-toast';
import { getDashboardData } from '@/services/localStorageService';

const Dashboard = () => {
  const { user } = useAuth();
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      fetchDashboardData();
    }
  }, [user]);

  const fetchDashboardData = () => {
    setLoading(true);
    
    try {
      if (!user) {
        throw new Error('User not found');
      }

      const data = getDashboardData(user.id);
      
      // If no data is returned, create default data based on user role
      if (!data) {
        const defaultData: DashboardData = {
          appointmentsCount: 0,
          patientsCount: 0,
          upcomingAppointments: [],
          recentActivities: [],
          activeCasesCount: 0,
          pendingTasksCount: 0
        };
        setDashboardData(defaultData);
        return;
      }

      setDashboardData(data);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      toast({
        title: "Error",
        description: "Failed to load dashboard data",
        variant: "destructive"
      });
      
      // Set default data even on error
      const defaultData: DashboardData = {
        appointmentsCount: 0,
        patientsCount: 0,
        upcomingAppointments: [],
        recentActivities: [],
        activeCasesCount: 0,
        pendingTasksCount: 0
      };
      setDashboardData(defaultData);
    } finally {
      setLoading(false);
    }
  };

  // Get appointment data for chart
  const getAppointmentChartData = () => {
    const daysOfWeek = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const today = new Date();
    const dayOfWeek = today.getDay(); // 0 = Sunday, 1 = Monday, ...
    const appointments = localStorage.getItem('healthcare_appointments');
    const parsedAppointments: Appointment[] = appointments ? JSON.parse(appointments) : [];
    
    let filteredAppointments: Appointment[] = [];
    if (user?.role === 'doctor') {
      filteredAppointments = parsedAppointments.filter(app => app.doctorId === user.id);
    } else if (user?.role === 'patient') {
      filteredAppointments = parsedAppointments.filter(app => app.patientId === user.id);
    } else {
      filteredAppointments = parsedAppointments;
    }
    
    // Initialize chart data with all days of the week
    const chartData = daysOfWeek.map(day => ({
      name: day,
      appointments: 0
    }));
    
    // Count appointments per day of the week
    filteredAppointments.forEach(appointment => {
      const appointmentDate = new Date(appointment.date);
      const appointmentDay = appointmentDate.getDay(); // 0 = Sunday, 1 = Monday, ...
      const dayIndex = appointmentDay === 0 ? 6 : appointmentDay - 1; // Convert to 0 = Monday, ..., 6 = Sunday
      chartData[dayIndex].appointments += 1;
    });
    
    return chartData;
  };

  if (loading) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-lg text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (!user || !dashboardData) {
    return (
      <div className="text-center py-8">
        <p className="text-lg text-gray-600">No dashboard data available.</p>
      </div>
    );
  }

  const renderWelcomeMessage = () => {
    const currentHour = new Date().getHours();
    let greeting = 'Good morning';
    
    if (currentHour >= 12 && currentHour < 17) {
      greeting = 'Good afternoon';
    } else if (currentHour >= 17) {
      greeting = 'Good evening';
    }
    
    return (
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">{greeting}, {user.first_name}</h1>
        <p className="text-muted-foreground">Here's your health dashboard for today</p>
      </div>
    );
  };

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  const formatTime = (timeString: string) => {
    const [hours, minutes] = timeString.split(':');
    const hour = parseInt(hours, 10);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const formatAppointmentTime = (appointment: Appointment) => {
    return `${formatTime(appointment.startTime)} - ${formatTime(appointment.endTime)}`;
  };

  const handleScheduleAppointment = () => {
    navigate('/appointments');
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {renderWelcomeMessage()}
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Appointments</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboardData.appointmentsCount}</div>
            <p className="text-xs text-muted-foreground">+20.1% from last month</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Patients</CardTitle>
            <User className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboardData.patientsCount}</div>
            <p className="text-xs text-muted-foreground">+180.1% from last month</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Cases</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboardData.activeCasesCount}</div>
            <p className="text-xs text-muted-foreground">Active patients with ongoing care</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Tasks</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboardData.pendingTasksCount}</div>
            <p className="text-xs text-muted-foreground">Upcoming appointments & pending prescriptions</p>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Appointments Overview</CardTitle>
            <CardDescription>Weekly appointment distribution</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={getAppointmentChartData()}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="appointments" fill="#8884d8" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Appointments</CardTitle>
            <CardDescription>Your next scheduled appointments</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {dashboardData.upcomingAppointments.map((appointment) => (
                <div key={appointment.id} className="flex items-center space-x-4">
                  <div className="flex-1">
                    <p className="text-sm font-medium">{appointment.reason}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatDate(appointment.date)} at {formatAppointmentTime(appointment)}
                    </p>
                  </div>
                  <Badge variant={appointment.status === 'scheduled' ? 'default' : 'secondary'}>
                    {appointment.status}
                  </Badge>
                </div>
              ))}
              {dashboardData.upcomingAppointments.length === 0 && (
                <p className="text-sm text-muted-foreground text-center">No upcoming appointments</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
          <CardDescription>Latest updates and actions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {dashboardData.recentActivities.map((activity) => (
              <div key={activity.id} className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  {activity.type === 'appointment' && <Calendar className="h-5 w-5 text-blue-500" />}
                  {activity.type === 'prescription' && <FileText className="h-5 w-5 text-green-500" />}
                  {activity.type === 'symptom' && <Activity className="h-5 w-5 text-red-500" />}
                </div>
                <div className="flex-1">
                  <p className="text-sm">{activity.description}</p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(activity.timestamp).toLocaleString()}
                  </p>
                </div>
              </div>
            ))}
            {dashboardData.recentActivities.length === 0 && (
              <p className="text-sm text-muted-foreground text-center">No recent activities</p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;
