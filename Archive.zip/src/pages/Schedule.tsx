
import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/components/ui/use-toast';
import { useIsMobile } from '@/hooks/use-mobile';
import { Calendar as CalendarIcon, Clock, ChevronLeft, ChevronRight, Plus } from 'lucide-react';
import { 
  getAppointments, 
  getUsersByRole, 
  saveAppointment,
  generateUUID 
} from '@/services/localStorageService';
import { Appointment } from '@/types/healthcare';

const Schedule = () => {
  const { user } = useAuth();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [view, setView] = useState<'day' | 'week'>('day');
  const [showAddAppointment, setShowAddAppointment] = useState(false);
  const isMobile = useIsMobile();
  
  // State for real users and appointments
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [patients, setPatients] = useState([]);
  const [doctors, setDoctors] = useState([]);

  const [newAppointment, setNewAppointment] = useState({
    patientId: '',
    doctorId: user?.role === 'doctor' ? user?.id : '',
    date: new Date().toISOString().split('T')[0],
    startTime: '09:00',
    endTime: '09:30',
    reason: '',
  });

  // Fetch real users and appointments from localStorage
  useEffect(() => {
    if (!user) return;
    
    // Get real appointments
    const allAppointments = getAppointments();
    setAppointments(allAppointments);
    
    // Get real users
    const patientUsers = getUsersByRole('patient');
    const doctorUsers = getUsersByRole('doctor');
    
    setPatients(patientUsers);
    setDoctors(doctorUsers);
  }, [user]);

  if (!user || (user.role !== 'doctor' && user.role !== 'receptionist')) {
    return (
      <div className="text-center py-10">
        <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
        <p className="text-muted-foreground">You don't have permission to view the schedule.</p>
      </div>
    );
  }

  const isDoctor = user.role === 'doctor';
  const isReceptionist = user.role === 'receptionist';

  // Filter appointments based on user role and date
  const filteredAppointments = appointments.filter(appointment => {
    // Filter by role
    if (isDoctor && appointment.doctorId !== user.id) return false;
    
    // Filter by date
    const appointmentDate = new Date(appointment.date);
    
    if (view === 'day') {
      return (
        appointmentDate.getFullYear() === currentDate.getFullYear() &&
        appointmentDate.getMonth() === currentDate.getMonth() &&
        appointmentDate.getDate() === currentDate.getDate()
      );
    } else if (view === 'week') {
      // Get start and end of week
      const startOfWeek = new Date(currentDate);
      startOfWeek.setDate(currentDate.getDate() - currentDate.getDay());
      const endOfWeek = new Date(startOfWeek);
      endOfWeek.setDate(startOfWeek.getDate() + 6);
      
      return appointmentDate >= startOfWeek && appointmentDate <= endOfWeek;
    }
    
    return true;
  });

  // Format date with day name
  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric'
    });
  };

  // Format time
  const formatTime = (timeString: string) => {
    const [hours, minutes] = timeString.split(':');
    const hour = parseInt(hours, 10);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  // Navigate through dates
  const navigateDate = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate);
    
    if (view === 'day') {
      newDate.setDate(currentDate.getDate() + (direction === 'next' ? 1 : -1));
    } else if (view === 'week') {
      newDate.setDate(currentDate.getDate() + (direction === 'next' ? 7 : -7));
    }
    
    setCurrentDate(newDate);
  };

  // Get week date range
  const getWeekRange = () => {
    const startOfWeek = new Date(currentDate);
    startOfWeek.setDate(currentDate.getDate() - currentDate.getDay());
    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6);
    
    const startMonth = startOfWeek.toLocaleDateString('en-US', { month: 'short' });
    const endMonth = endOfWeek.toLocaleDateString('en-US', { month: 'short' });
    const startDay = startOfWeek.getDate();
    const endDay = endOfWeek.getDate();
    const year = startOfWeek.getFullYear();
    
    return `${startMonth} ${startDay} - ${endMonth} ${endDay}, ${year}`;
  };

  // Generate time slots
  const timeSlots = [];
  for (let i = 8; i <= 17; i++) { // 8 AM to 5 PM
    timeSlots.push(`${i < 10 ? '0' + i : i}:00`);
    timeSlots.push(`${i < 10 ? '0' + i : i}:30`);
  }

  const handleAddAppointment = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    if (!newAppointment.patientId || !newAppointment.doctorId || !newAppointment.date || !newAppointment.startTime || !newAppointment.reason) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    // Calculate end time (30 minutes after start)
    const calculateEndTime = (startTime: string) => {
      const [hours, minutes] = startTime.split(':').map(Number);
      let newHours = hours;
      let newMinutes = minutes + 30;
      
      if (newMinutes >= 60) {
        newHours = (newHours + 1) % 24;
        newMinutes = newMinutes % 60;
      }
      
      return `${newHours.toString().padStart(2, '0')}:${newMinutes.toString().padStart(2, '0')}`;
    };

    // Create new appointment with the correct type for status
    const appointment: Appointment = {
      id: generateUUID(),
      patientId: newAppointment.patientId,
      doctorId: newAppointment.doctorId,
      date: newAppointment.date,
      startTime: newAppointment.startTime,
      endTime: newAppointment.endTime || calculateEndTime(newAppointment.startTime),
      reason: newAppointment.reason,
      status: 'scheduled', // Using the literal type
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    // Save to localStorage
    saveAppointment(appointment);
    
    // Update local state
    setAppointments([...appointments, appointment]);

    toast({
      title: "Appointment Scheduled",
      description: `Appointment has been scheduled for ${formatDate(new Date(newAppointment.date))}`
    });

    // Close the dialog
    setShowAddAppointment(false);
    
    // Reset the form
    setNewAppointment({
      patientId: '',
      doctorId: user?.role === 'doctor' ? user?.id : '',
      date: new Date().toISOString().split('T')[0],
      startTime: '09:00',
      endTime: '09:30',
      reason: '',
    });
  };

  // Find user name helper function
  const getUserName = (userId) => {
    const foundInPatients = patients.find(p => p.id === userId);
    if (foundInPatients) {
      return `${foundInPatients.first_name} ${foundInPatients.last_name}`;
    }
    
    const foundInDoctors = doctors.find(d => d.id === userId);
    if (foundInDoctors) {
      return `Dr. ${foundInDoctors.first_name} ${foundInDoctors.last_name}`;
    }
    
    return "Unknown User";
  };

  return (
    <div className="fade-in">
      <div className="flex flex-col space-y-2 md:flex-row md:justify-between md:items-center mb-6">
        <div>
          <h2 className="text-2xl md:text-3xl font-bold tracking-tight mb-1">Schedule</h2>
          <p className="text-sm text-muted-foreground">
            {view === 'day' ? formatDate(currentDate) : getWeekRange()}
          </p>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm" onClick={() => navigateDate('prev')} className="px-2">
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setCurrentDate(new Date())}
            className="text-xs md:text-sm"
          >
            Today
          </Button>
          <Button variant="outline" size="sm" onClick={() => navigateDate('next')} className="px-2">
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Tabs value={view} onValueChange={(v) => setView(v as 'day' | 'week')}>
        <div className="flex items-center justify-between mb-4">
          <TabsList>
            <TabsTrigger value="day">Day</TabsTrigger>
            <TabsTrigger value="week">Week</TabsTrigger>
          </TabsList>
          
          <Button size="sm" onClick={() => setShowAddAppointment(true)}>
            <Plus className="h-4 w-4 mr-1 md:mr-2" /> 
            {isMobile ? 'Add' : 'Add Appointment'}
          </Button>
        </div>
        
        <TabsContent value="day" className="m-0">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center text-lg">
                <CalendarIcon className="mr-2 h-5 w-5" />
                {isMobile ? currentDate.toLocaleDateString('en-US', {
                  month: 'short',
                  day: 'numeric'
                }) : formatDate(currentDate)}
              </CardTitle>
              <CardDescription>
                {isDoctor ? "Your appointments for today" : "All appointments for today"}
              </CardDescription>
            </CardHeader>
            <CardContent className="p-2 md:p-4">
              <div className="space-y-1 overflow-hidden">
                {timeSlots.map(timeSlot => {
                  // Find appointments that match this time slot
                  const appointmentsAtTime = filteredAppointments.filter(
                    apt => apt.startTime === timeSlot
                  );
                  
                  return (
                    <div 
                      key={timeSlot} 
                      className={`grid grid-cols-[60px_1fr] md:grid-cols-[80px_1fr] gap-2 md:gap-4 p-1 md:p-2 rounded-md ${
                        appointmentsAtTime.length > 0 ? 'bg-muted/30' : ''
                      }`}
                    >
                      <div className="flex items-center">
                        <Clock className="h-3 w-3 mr-1 text-muted-foreground" />
                        <span className="text-xs md:text-sm">{formatTime(timeSlot)}</span>
                      </div>
                      
                      <div className="flex flex-col gap-1 min-h-[40px]">
                        {appointmentsAtTime.length > 0 ? (
                          appointmentsAtTime.map(apt => {
                            const patientName = getUserName(apt.patientId);
                            const doctorName = getUserName(apt.doctorId);
                            
                            return (
                              <div 
                                key={apt.id} 
                                className="bg-primary text-primary-foreground p-2 rounded-md text-xs md:text-sm w-full"
                              >
                                <p className="font-medium truncate">{apt.reason}</p>
                                <div className="flex flex-col md:flex-row md:items-center md:justify-between text-xs mt-1">
                                  <span className="truncate">{isDoctor ? `Patient: ${patientName}` : `Doctor: ${doctorName}`}</span>
                                  <span className="text-[10px] md:text-xs">{formatTime(apt.startTime)} - {formatTime(apt.endTime)}</span>
                                </div>
                                <div className="mt-2 text-right">
                                  <Button size="sm" variant="secondary" className="text-xs h-6 md:h-7 px-2">
                                    View Details
                                  </Button>
                                </div>
                              </div>
                            );
                          })
                        ) : null}
                      </div>
                    </div>
                  );
                })}
                
                {filteredAppointments.length === 0 && (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">No appointments scheduled for this day</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="week" className="m-0">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-lg">
                <CalendarIcon className="mr-2 h-5 w-5" />
                {getWeekRange()}
              </CardTitle>
              <CardDescription>
                {isDoctor ? "Your weekly schedule" : "All appointments for the week"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <p className="text-muted-foreground">Weekly view will display a calendar grid with appointments</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Add Appointment Dialog */}
      <Dialog open={showAddAppointment} onOpenChange={setShowAddAppointment}>
        <DialogContent className={`sm:max-w-[500px] ${isMobile ? 'w-[95vw] max-h-[80vh] overflow-y-auto p-4' : ''}`}>
          <DialogHeader>
            <DialogTitle>Schedule New Appointment</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleAddAppointment}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="date">Date</Label>
                  <Input
                    id="date"
                    type="date"
                    value={newAppointment.date}
                    onChange={(e) => setNewAppointment({...newAppointment, date: e.target.value})}
                    required
                    className="h-9"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="time">Start Time</Label>
                  <Select 
                    value={newAppointment.startTime} 
                    onValueChange={(value) => setNewAppointment({...newAppointment, startTime: value})}
                  >
                    <SelectTrigger id="time" className="h-9">
                      <SelectValue placeholder="Select time" />
                    </SelectTrigger>
                    <SelectContent>
                      {timeSlots.map((time) => (
                        <SelectItem key={time} value={time}>
                          {formatTime(time)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {isReceptionist && (
                <div className="space-y-2">
                  <Label htmlFor="doctor">Doctor</Label>
                  <Select 
                    value={newAppointment.doctorId} 
                    onValueChange={(value) => setNewAppointment({...newAppointment, doctorId: value})}
                  >
                    <SelectTrigger id="doctor" className="h-9">
                      <SelectValue placeholder="Select doctor" />
                    </SelectTrigger>
                    <SelectContent position={isMobile ? "popper" : "item-aligned"}>
                      {doctors.map((doctor) => (
                        <SelectItem key={doctor.id} value={doctor.id}>
                          Dr. {doctor.first_name} {doctor.last_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="patient">Patient</Label>
                <Select 
                  value={newAppointment.patientId} 
                  onValueChange={(value) => setNewAppointment({...newAppointment, patientId: value})}
                >
                  <SelectTrigger id="patient" className="h-9">
                    <SelectValue placeholder="Select patient" />
                  </SelectTrigger>
                  <SelectContent position={isMobile ? "popper" : "item-aligned"}>
                    {patients.map((patient) => (
                      <SelectItem key={patient.id} value={patient.id}>
                        {patient.first_name} {patient.last_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="reason">Reason for Visit</Label>
                <Textarea
                  id="reason"
                  placeholder="Briefly describe the reason for this appointment"
                  value={newAppointment.reason}
                  onChange={(e) => setNewAppointment({...newAppointment, reason: e.target.value})}
                  className="h-20 resize-none"
                  required
                />
              </div>
            </div>
            <DialogFooter className="mt-2">
              <Button type="submit">Schedule Appointment</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Schedule;
