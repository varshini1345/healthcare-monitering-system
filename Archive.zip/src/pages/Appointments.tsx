
import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Calendar } from '@/components/ui/calendar';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { 
  getAppointmentsByDoctorId, 
  getAppointmentsByPatientId, 
  getAppointments, 
  saveAppointment,
  getUserById,
  getUsersByRole,
  getDoctorByUserId,
  getPatientByUserId,
  generateUUID
} from '@/services/localStorageService';
import { Appointment, SymptomReport } from '@/types/healthcare';

const AppointmentsPage = () => {
  const { user } = useAuth();
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [activeTab, setActiveTab] = useState('upcoming');
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const { toast } = useToast();
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isSymptomModalOpen, setIsSymptomModalOpen] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  
  // Form states for new appointment
  const [selectedDoctor, setSelectedDoctor] = useState<string>('');
  const [selectedPatient, setSelectedPatient] = useState<string>('');
  const [appointmentDate, setAppointmentDate] = useState<Date | undefined>(new Date());
  const [startTime, setStartTime] = useState<string>('09:00');
  const [endTime, setEndTime] = useState<string>('09:30');
  const [reason, setReason] = useState<string>('');
  const [symptoms, setSymptoms] = useState<string>('');
  
  // State for doctors and patients lists
  const [doctors, setDoctors] = useState<{id: string; name: string}[]>([]);
  const [patients, setPatients] = useState<{id: string; name: string}[]>([]);

  // Symptom report form state
  const [symptomDescription, setSymptomDescription] = useState('');
  const [symptomSeverity, setSymptomSeverity] = useState<'mild' | 'moderate' | 'severe'>('moderate');
  const [symptomDuration, setSymptomDuration] = useState('');

  useEffect(() => {
    if (!user) return;

    // Load appointments based on user role
    loadAppointments();
    
    // Load doctors and patients for appointment creation
    if (user.role === 'admin' || user.role === 'receptionist') {
      loadDoctorsAndPatients();
    } else if (user.role === 'patient') {
      loadDoctors();
    } else if (user.role === 'doctor') {
      loadPatients();
    }
  }, [user]);

  const loadAppointments = () => {
    if (!user) return;
    
    let userAppointments: Appointment[] = [];
    
    if (user.role === 'doctor') {
      userAppointments = getAppointmentsByDoctorId(user.id);
    } else if (user.role === 'patient') {
      userAppointments = getAppointmentsByPatientId(user.id);
    } else {
      // Admin or receptionist can see all appointments
      userAppointments = getAppointments();
    }
    
    setAppointments(userAppointments);
  };

  const loadDoctorsAndPatients = () => {
    const doctorUsers = getUsersByRole('doctor');
    const patientUsers = getUsersByRole('patient');
    
    setDoctors(doctorUsers.map(d => ({
      id: d.id,
      name: `Dr. ${d.first_name} ${d.last_name}`
    })));
    
    setPatients(patientUsers.map(p => ({
      id: p.id,
      name: `${p.first_name} ${p.last_name}`
    })));
  };
  
  const loadDoctors = () => {
    const doctorUsers = getUsersByRole('doctor');
    setDoctors(doctorUsers.map(d => ({
      id: d.id,
      name: `Dr. ${d.first_name} ${d.last_name}`
    })));
  };
  
  const loadPatients = () => {
    if (!user) return;
    
    const doctorInfo = getDoctorByUserId(user.id);
    if (!doctorInfo) return;
    
    const patientUsers = getUsersByRole('patient');
    setPatients(patientUsers.map(p => ({
      id: p.id,
      name: `${p.first_name} ${p.last_name}`
    })));
  };

  // Filter appointments based on the active tab
  const filteredAppointments = appointments
    .filter(appointment => {
      if (searchQuery) {
        const doctorName = getUserById(appointment.doctorId)?.last_name?.toLowerCase() || '';
        const patientName = getUserById(appointment.patientId)?.last_name?.toLowerCase() || '';
        const searchLower = searchQuery.toLowerCase();
        return doctorName.includes(searchLower) || 
               patientName.includes(searchLower) ||
               appointment.reason.toLowerCase().includes(searchLower);
      }
      return true;
    })
    .filter(appointment => {
      if (activeTab === 'upcoming') {
        return appointment.status === 'scheduled';
      } else if (activeTab === 'completed') {
        return appointment.status === 'completed';
      } else {
        return appointment.status === 'cancelled';
      }
    });

  const handleCreateAppointment = () => {
    if (!user || !appointmentDate) return;
    
    const newAppointment: Appointment = {
      id: generateUUID(),
      patientId: user.role === 'patient' ? user.id : selectedPatient,
      doctorId: user.role === 'doctor' ? user.id : selectedDoctor,
      date: appointmentDate.toISOString().split('T')[0],
      startTime,
      endTime,
      reason,
      symptoms,
      status: 'scheduled',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    try {
      saveAppointment(newAppointment);
      toast({
        title: "Success",
        description: "Appointment scheduled successfully",
      });
      setIsCreateModalOpen(false);
      resetAppointmentForm();
      loadAppointments();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to schedule appointment",
        variant: "destructive",
      });
    }
  };

  const handleUpdateAppointmentStatus = (appointmentId: string, status: 'scheduled' | 'cancelled' | 'completed') => {
    const appointmentToUpdate = appointments.find(a => a.id === appointmentId);
    if (!appointmentToUpdate) return;
    
    const updatedAppointment = {
      ...appointmentToUpdate,
      status,
      updated_at: new Date().toISOString()
    };
    
    try {
      saveAppointment(updatedAppointment);
      toast({
        title: "Success",
        description: `Appointment ${status} successfully`,
      });
      loadAppointments();
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to update appointment status`,
        variant: "destructive",
      });
    }
  };

  const resetAppointmentForm = () => {
    setSelectedDoctor('');
    setSelectedPatient('');
    setAppointmentDate(new Date());
    setStartTime('09:00');
    setEndTime('09:30');
    setReason('');
    setSymptoms('');
  };

  const openSymptomModal = (appointment: Appointment) => {
    setSelectedAppointment(appointment);
    setIsSymptomModalOpen(true);
  };

  const handleAddSymptoms = () => {
    if (!selectedAppointment || !user) return;
    
    // Update appointment with symptoms
    const updatedAppointment = {
      ...selectedAppointment,
      symptoms: symptomDescription,
      updated_at: new Date().toISOString()
    };
    
    try {
      // Save updated appointment with symptoms
      saveAppointment(updatedAppointment);
      
      // Create symptom report
      const patientInfo = getPatientByUserId(user.id);
      if (patientInfo) {
        // In a real app, we would save this to a symptom reports collection
        // Here we're just showing the capability
      }
      
      toast({
        title: "Success",
        description: "Symptoms added to your appointment",
      });
      setIsSymptomModalOpen(false);
      setSymptomDescription('');
      setSymptomSeverity('moderate');
      setSymptomDuration('');
      loadAppointments();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add symptoms",
        variant: "destructive",
      });
    }
  };

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  const formatTime = (timeString: string) => {
    const [hours, minutes] = timeString.split(':');
    const hour = parseInt(hours, 10);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled': return 'default';
      case 'completed': return 'success';
      case 'cancelled': return 'destructive';
      default: return 'secondary';
    }
  };

  if (!user) return null;

  return (
    <div className="fade-in">
      <div className="flex flex-col lg:flex-row justify-between items-start mb-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight mb-2">Appointments</h2>
          <p className="text-muted-foreground">View and manage your healthcare appointments</p>
        </div>
        
        {(user.role === 'patient' || user.role === 'admin' || user.role === 'receptionist' || user.role === 'doctor') && (
          <Button 
            className="mt-4 lg:mt-0"
            onClick={() => setIsCreateModalOpen(true)}
          >
            Schedule New Appointment
          </Button>
        )}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <CardTitle>Appointments</CardTitle>
                  <CardDescription>View and manage your appointments</CardDescription>
                </div>
                <div className="flex items-center space-x-2">
                  <Input 
                    placeholder="Search appointments..." 
                    className="max-w-[180px]"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="upcoming" onValueChange={setActiveTab}>
                <TabsList className="mb-4">
                  <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
                  <TabsTrigger value="completed">Completed</TabsTrigger>
                  <TabsTrigger value="cancelled">Cancelled</TabsTrigger>
                </TabsList>
                
                <TabsContent value={activeTab} className="space-y-4">
                  {filteredAppointments.length > 0 ? (
                    filteredAppointments.map(appointment => {
                      const doctorUser = getUserById(appointment.doctorId);
                      const patientUser = getUserById(appointment.patientId);
                      const doctorName = doctorUser ? `Dr. ${doctorUser.first_name} ${doctorUser.last_name}` : 'Unknown Doctor';
                      const patientName = patientUser ? `${patientUser.first_name} ${patientUser.last_name}` : 'Unknown Patient';
                      
                      return (
                        <div key={appointment.id} className="border rounded-md p-4 flex items-start">
                          <div className="flex flex-col items-center mr-4 min-w-[80px] text-center">
                            <div className="text-3xl font-bold">
                              {new Date(appointment.date).getDate()}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {new Date(appointment.date).toLocaleString('default', { month: 'short' })}
                            </div>
                          </div>
                          
                          <div className="flex-1">
                            <div className="flex flex-col md:flex-row md:items-center justify-between mb-2">
                              <h4 className="font-semibold">{appointment.reason}</h4>
                              <Badge variant={getStatusColor(appointment.status) as any}>
                                {appointment.status}
                              </Badge>
                            </div>
                            
                            <p className="text-sm mb-2">
                              <span className="text-muted-foreground">Time: </span>
                              {formatTime(appointment.startTime)} - {formatTime(appointment.endTime)}
                            </p>
                            
                            <div className="flex flex-col md:flex-row gap-2 md:gap-4 text-sm">
                              <p>
                                <span className="text-muted-foreground">Doctor: </span>
                                {doctorName}
                              </p>
                              
                              {(user.role === 'doctor' || user.role === 'admin' || user.role === 'receptionist') && (
                                <p>
                                  <span className="text-muted-foreground">Patient: </span>
                                  {patientName}
                                </p>
                              )}
                            </div>
                            
                            {appointment.symptoms && (
                              <p className="mt-2 text-sm">
                                <span className="text-muted-foreground">Symptoms: </span>
                                {appointment.symptoms}
                              </p>
                            )}
                            
                            {appointment.notes && (
                              <p className="mt-1 text-sm text-muted-foreground">
                                Notes: {appointment.notes}
                              </p>
                            )}
                          </div>
                          
                          <div className="ml-4 flex flex-col space-y-2">
                            {appointment.status === 'scheduled' && (
                              <>
                                {user.role === 'patient' && (
                                  <Button 
                                    variant="outline" 
                                    size="sm"
                                    onClick={() => openSymptomModal(appointment)}
                                  >
                                    Add Symptoms
                                  </Button>
                                )}
                                {(user.role === 'doctor' || user.role === 'admin' || user.role === 'receptionist') && (
                                  <Button 
                                    variant="outline" 
                                    size="sm"
                                    onClick={() => handleUpdateAppointmentStatus(appointment.id, 'completed')}
                                  >
                                    Mark Complete
                                  </Button>
                                )}
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="text-destructive"
                                  onClick={() => handleUpdateAppointmentStatus(appointment.id, 'cancelled')}
                                >
                                  Cancel
                                </Button>
                              </>
                            )}
                            
                            {appointment.status === 'completed' && (
                              <Button variant="outline" size="sm">
                                View Details
                              </Button>
                            )}
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-muted-foreground">No {activeTab} appointments found</p>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
        
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Calendar</CardTitle>
              <CardDescription>Select a date to view or schedule appointments</CardDescription>
            </CardHeader>
            <CardContent>
              <Calendar 
                mode="single"
                selected={date}
                onSelect={setDate}
                className="rounded-md border pointer-events-auto"
              />
            </CardContent>
          </Card>
          
          {user.role === 'patient' && (
            <Card>
              <CardHeader>
                <CardTitle>Share Health Information</CardTitle>
                <CardDescription>Report symptoms to your doctor</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm mb-4">
                  Help your doctor prepare for your appointment by sharing your symptoms in advance.
                </p>
                <Button 
                  className="w-full" 
                  onClick={() => {
                    // Find next appointment
                    const nextAppointment = appointments
                      .filter(a => a.status === 'scheduled')
                      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())[0];
                    
                    if (nextAppointment) {
                      setSelectedAppointment(nextAppointment);
                      setIsSymptomModalOpen(true);
                    } else {
                      toast({
                        title: "No upcoming appointments",
                        description: "Please schedule an appointment first",
                      });
                    }
                  }}
                >
                  Report Symptoms
                </Button>
              </CardContent>
            </Card>
          )}
          
          {(user.role === 'admin' || user.role === 'receptionist') && (
            <Card>
              <CardHeader>
                <CardTitle>Quick Schedule</CardTitle>
                <CardDescription>Create a new appointment</CardDescription>
              </CardHeader>
              <CardContent>
                <form className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="quickPatient">Patient</Label>
                    <Select
                      value={selectedPatient}
                      onValueChange={setSelectedPatient}
                    >
                      <SelectTrigger id="quickPatient">
                        <SelectValue placeholder="Select patient" />
                      </SelectTrigger>
                      <SelectContent>
                        {patients.map(patient => (
                          <SelectItem key={patient.id} value={patient.id}>
                            {patient.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="quickDoctor">Doctor</Label>
                    <Select
                      value={selectedDoctor}
                      onValueChange={setSelectedDoctor}
                    >
                      <SelectTrigger id="quickDoctor">
                        <SelectValue placeholder="Select doctor" />
                      </SelectTrigger>
                      <SelectContent>
                        {doctors.map(doctor => (
                          <SelectItem key={doctor.id} value={doctor.id}>
                            {doctor.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="quickReason">Reason</Label>
                    <Input 
                      id="quickReason"
                      placeholder="Reason for appointment" 
                      value={reason}
                      onChange={(e) => setReason(e.target.value)}
                    />
                  </div>
                  
                  <Button 
                    type="button" 
                    className="w-full"
                    onClick={handleCreateAppointment}
                    disabled={!selectedPatient || !selectedDoctor || !reason || !appointmentDate}
                  >
                    Schedule Appointment
                  </Button>
                </form>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Create Appointment Modal */}
      <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
        <DialogContent className="sm:max-w-[525px]">
          <DialogHeader>
            <DialogTitle>Schedule New Appointment</DialogTitle>
            <DialogDescription>
              Enter the details for the new appointment.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            {user.role !== 'patient' && (
              <div className="grid gap-2">
                <Label htmlFor="patient">Patient</Label>
                <Select
                  value={selectedPatient}
                  onValueChange={setSelectedPatient}
                >
                  <SelectTrigger id="patient">
                    <SelectValue placeholder="Select patient" />
                  </SelectTrigger>
                  <SelectContent>
                    {patients.map(patient => (
                      <SelectItem key={patient.id} value={patient.id}>
                        {patient.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            
            {user.role !== 'doctor' && (
              <div className="grid gap-2">
                <Label htmlFor="doctor">Doctor</Label>
                <Select
                  value={selectedDoctor}
                  onValueChange={setSelectedDoctor}
                >
                  <SelectTrigger id="doctor">
                    <SelectValue placeholder="Select doctor" />
                  </SelectTrigger>
                  <SelectContent>
                    {doctors.map(doctor => (
                      <SelectItem key={doctor.id} value={doctor.id}>
                        {doctor.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            
            <div className="grid gap-2">
              <Label>Date</Label>
              <Calendar 
                mode="single"
                selected={appointmentDate}
                onSelect={setAppointmentDate}
                className="rounded-md border pointer-events-auto"
                disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="startTime">Start Time</Label>
                <Input 
                  id="startTime" 
                  type="time" 
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="endTime">End Time</Label>
                <Input 
                  id="endTime" 
                  type="time"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                />
              </div>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="reason">Reason</Label>
              <Input 
                id="reason"
                placeholder="Reason for appointment" 
                value={reason}
                onChange={(e) => setReason(e.target.value)}
              />
            </div>
            
            {user.role === 'patient' && (
              <div className="grid gap-2">
                <Label htmlFor="symptoms">Symptoms (optional)</Label>
                <Textarea
                  id="symptoms"
                  placeholder="Describe your symptoms" 
                  value={symptoms}
                  onChange={(e) => setSymptoms(e.target.value)}
                  rows={3}
                />
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateModalOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleCreateAppointment} 
              disabled={
                (user.role !== 'patient' && !selectedPatient) ||
                (user.role !== 'doctor' && !selectedDoctor) ||
                !appointmentDate || 
                !reason
              }
            >
              Schedule
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Symptom Report Modal */}
      <Dialog open={isSymptomModalOpen} onOpenChange={setIsSymptomModalOpen}>
        <DialogContent className="sm:max-w-[525px]">
          <DialogHeader>
            <DialogTitle>Report Symptoms</DialogTitle>
            <DialogDescription>
              Share your symptoms with your doctor before your appointment.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="symptomDescription">Description</Label>
              <Textarea 
                id="symptomDescription"
                placeholder="Describe your symptoms in detail"
                value={symptomDescription}
                onChange={(e) => setSymptomDescription(e.target.value)}
                rows={4}
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="severity">Severity</Label>
              <Select
                value={symptomSeverity}
                onValueChange={(value) => setSymptomSeverity(value as 'mild' | 'moderate' | 'severe')}
              >
                <SelectTrigger id="severity">
                  <SelectValue placeholder="Select severity" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mild">Mild</SelectItem>
                  <SelectItem value="moderate">Moderate</SelectItem>
                  <SelectItem value="severe">Severe</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="duration">Duration</Label>
              <Input
                id="duration"
                placeholder="How long have you been experiencing these symptoms?"
                value={symptomDuration}
                onChange={(e) => setSymptomDuration(e.target.value)}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsSymptomModalOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleAddSymptoms}
              disabled={!symptomDescription}
            >
              Submit Symptoms
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AppointmentsPage;
