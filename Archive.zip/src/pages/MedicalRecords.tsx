
import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { FileText, Download, Plus, Search } from 'lucide-react';
import { 
  getMedicalRecords, 
  getMedicalRecordsByPatientId,
  getMedicalRecordsByDoctorId,
  getUserById,
  saveMedicalRecord,
  getUsersByRole
} from '@/services/localStorageService';
import { MedicalRecord } from '@/types/healthcare';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from 'react-hook-form';
import { toast } from '@/components/ui/use-toast';

interface NewRecordFormData {
  title: string;
  description: string;
  patientId: string;
  doctorId: string;
  type: 'visit' | 'lab' | 'procedure' | 'other';
}

const MedicalRecords = () => {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [records, setRecords] = useState<MedicalRecord[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [patients, setPatients] = useState<{id: string, name: string}[]>([]);
  const [doctors, setDoctors] = useState<{id: string, name: string}[]>([]);
  
  const form = useForm<NewRecordFormData>({
    defaultValues: {
      title: '',
      description: '',
      patientId: '',
      doctorId: user?.role === 'doctor' ? user.id : '',
      type: 'visit'
    }
  });

  useEffect(() => {
    if (user) {
      loadMedicalRecords();
      loadUsersForForm();
    }
  }, [user]);

  const loadUsersForForm = () => {
    // Load patients
    const patientUsers = getUsersByRole('patient');
    const patientList = patientUsers.map(p => ({
      id: p.id,
      name: `${p.first_name} ${p.last_name}`
    }));
    setPatients(patientList);
    
    // Load doctors
    const doctorUsers = getUsersByRole('doctor');
    const doctorList = doctorUsers.map(d => ({
      id: d.id,
      name: `Dr. ${d.first_name} ${d.last_name}`
    }));
    setDoctors(doctorList);
  };

  const loadMedicalRecords = () => {
    if (!user) return;

    let filteredRecords: MedicalRecord[] = [];
    
    if (user.role === 'patient') {
      filteredRecords = getMedicalRecordsByPatientId(user.id);
    } else if (user.role === 'doctor') {
      filteredRecords = getMedicalRecordsByDoctorId(user.id);
    } else {
      // Admin, receptionist, etc. can see all records
      filteredRecords = getMedicalRecords();
    }
    
    setRecords(filteredRecords);
  };
  
  const handleAddNewRecord = (data: NewRecordFormData) => {
    if (!user) return;
    
    try {
      // Create new record object
      const newRecord: MedicalRecord = {
        id: generateUUID(),
        patientId: data.patientId,
        doctorId: data.doctorId,
        date: new Date().toISOString(),
        title: data.title,
        description: data.description,
        type: data.type,
        status: 'active',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      // Add record to storage - use saveMedicalRecord instead of addMedicalRecord
      saveMedicalRecord(newRecord);
      
      // Success message
      toast({
        title: "Record Added",
        description: "Medical record has been added successfully",
      });
      
      // Reset form and close dialog
      form.reset();
      setDialogOpen(false);
      
      // Refresh records
      loadMedicalRecords();
    } catch (error) {
      console.error("Error adding record:", error);
      toast({
        title: "Error",
        description: "Failed to add medical record",
        variant: "destructive"
      });
    }
  };

  const openAddRecordDialog = () => {
    form.reset({
      title: '',
      description: '',
      patientId: '',
      doctorId: user?.role === 'doctor' ? user.id : '',
      type: 'visit'
    });
    setDialogOpen(true);
  };

  // Helper function to generate UUIDs
  const generateUUID = () => {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  };

  if (!user) return null;

  const isPatient = user.role === 'patient';
  const isDoctor = user.role === 'doctor';
  const isAdmin = user.role === 'admin';

  // Apply search filter
  const displayedRecords = searchQuery
    ? records.filter(record => 
        record.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
        record.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : records;

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  const getRecordTypeIcon = (type: string) => {
    return <FileText className="h-5 w-5" />;
  };

  const getTypeLabel = (type: string) => {
    return type.charAt(0).toUpperCase() + type.slice(1);
  };

  const getDoctorName = (doctorId: string) => {
    const doctor = getUserById(doctorId);
    return doctor ? `Dr. ${doctor.first_name} ${doctor.last_name}` : 'Unknown Doctor';
  };

  const getPatientName = (patientId: string) => {
    const patient = getUserById(patientId);
    return patient ? `${patient.first_name} ${patient.last_name}` : 'Unknown Patient';
  };

  return (
    <div className="fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start mb-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight mb-2">Medical Records</h2>
          <p className="text-muted-foreground">View and manage health records</p>
        </div>
        
        {(isDoctor || isAdmin) && (
          <Button className="mt-4 md:mt-0" onClick={openAddRecordDialog}>
            <Plus className="mr-2 h-4 w-4" /> Add New Record
          </Button>
        )}
      </div>

      <Card>
        <CardHeader className="flex flex-col md:flex-row items-start md:items-center justify-between space-y-2 md:space-y-0">
          <div>
            <CardTitle>Health Records</CardTitle>
            <CardDescription>View and manage your medical documentation</CardDescription>
          </div>
          
          <div className="w-full md:w-auto">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search records..."
                className="w-full md:w-[250px] pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          <Tabs defaultValue="all">
            <TabsList className="mb-4">
              <TabsTrigger value="all">All Records</TabsTrigger>
              <TabsTrigger value="visits">Visits</TabsTrigger>
              <TabsTrigger value="labs">Lab Results</TabsTrigger>
              <TabsTrigger value="other">Other</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all" className="space-y-4">
              {displayedRecords.length > 0 ? (
                displayedRecords.map(record => {
                  const doctorName = getDoctorName(record.doctorId);
                  const patientName = getPatientName(record.patientId);
                  
                  return (
                    <div key={record.id} className="border rounded-md p-4 hover:bg-muted/5 transition-colors">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary mr-4">
                            {getRecordTypeIcon(record.type)}
                          </div>
                          
                          <div>
                            <div className="flex items-center gap-2">
                              <h3 className="font-medium">{record.title}</h3>
                              <Badge variant="outline">{getTypeLabel(record.type)}</Badge>
                              {record.status === 'active' && (
                                <Badge variant="secondary">Active</Badge>
                              )}
                            </div>
                            
                            <p className="text-sm text-muted-foreground mt-1">
                              {formatDate(record.date)}
                            </p>
                            
                            <div className="mt-2 text-sm">
                              <p className="line-clamp-2">{record.description}</p>
                            </div>
                            
                            <div className="flex flex-col sm:flex-row gap-2 sm:gap-4 mt-2 text-sm">
                              {!isPatient && (
                                <div>
                                  <span className="text-muted-foreground">Patient: </span>
                                  {patientName}
                                </div>
                              )}
                              
                              <div>
                                <span className="text-muted-foreground">Doctor: </span>
                                {doctorName}
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm">
                            View
                          </Button>
                          
                          {record.attachments && record.attachments.length > 0 && (
                            <Button variant="ghost" size="sm">
                              <Download className="h-4 w-4 mr-1" /> Files
                            </Button>
                          )}
                        </div>
                      </div>
                      
                      {record.attachments && record.attachments.length > 0 && (
                        <div className="mt-4 border-t pt-2">
                          <p className="text-xs text-muted-foreground mb-2">Attachments:</p>
                          <div className="flex flex-wrap gap-2">
                            {record.attachments.map((attachment, index) => (
                              <Badge key={index} variant="outline" className="bg-muted/50">
                                <FileText className="h-3 w-3 mr-1" />
                                {attachment}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-10 border rounded-md">
                  <FileText className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                  <h3 className="font-medium mb-1">No records found</h3>
                  <p className="text-muted-foreground text-sm mb-4">
                    {searchQuery ? "No results match your search criteria." : "You have no medical records yet."}
                  </p>
                  
                  {(isDoctor || isAdmin) && (
                    <Button onClick={openAddRecordDialog}>
                      <Plus className="mr-2 h-4 w-4" /> Add New Record
                    </Button>
                  )}
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="visits">
              <div className="text-center py-8">
                <p className="text-muted-foreground">Filter by visit records</p>
              </div>
            </TabsContent>
            
            <TabsContent value="labs">
              <div className="text-center py-8">
                <p className="text-muted-foreground">Filter by lab results</p>
              </div>
            </TabsContent>
            
            <TabsContent value="other">
              <div className="text-center py-8">
                <p className="text-muted-foreground">Filter by other record types</p>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Add New Record Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Add New Medical Record</DialogTitle>
            <DialogDescription>
              Create a new medical record entry
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleAddNewRecord)} className="space-y-4">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Record Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter record title" {...field} required />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Record Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select record type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="visit">Visit</SelectItem>
                        <SelectItem value="lab">Lab Results</SelectItem>
                        <SelectItem value="procedure">Procedure</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
              
              {!isPatient && (
                <FormField
                  control={form.control}
                  name="patientId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Patient</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select patient" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {patients.map(patient => (
                            <SelectItem key={patient.id} value={patient.id}>
                              {patient.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )}
                />
              )}
              
              {!isDoctor && (
                <FormField
                  control={form.control}
                  name="doctorId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Doctor</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select doctor" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {doctors.map(doctor => (
                            <SelectItem key={doctor.id} value={doctor.id}>
                              {doctor.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )}
                />
              )}
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Enter record details" 
                        className="h-24"
                        {...field} 
                        required 
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button variant="outline" type="button" onClick={() => setDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  <Plus className="mr-2 h-4 w-4" /> Add Record
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default MedicalRecords;
