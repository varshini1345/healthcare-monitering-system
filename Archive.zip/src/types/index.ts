
export type UserRole = 'admin' | 'doctor' | 'patient' | 'pharmacist' | 'receptionist';

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  avatar?: string;
}

export interface Patient {
  id: string;
  userId: string;
  dateOfBirth: string;
  gender: 'male' | 'female' | 'other';
  bloodType?: 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
  allergies: string[];
  medicalConditions: string[];
  contactNumber: string;
  emergencyContact?: {
    name: string;
    relationship: string;
    contactNumber: string;
  };
}

export interface Doctor {
  id: string;
  userId: string;
  specialization: string;
  licenseNumber: string;
  yearsOfExperience: number;
  education: string[];
  schedule: {
    dayOfWeek: number;
    startTime: string;
    endTime: string;
  }[];
  contactNumber: string;
}

export interface Appointment {
  id: string;
  patientId: string;
  doctorId: string;
  date: string;
  startTime: string;
  endTime: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  reason: string;
  notes?: string;
  createdAt: string;
}

export interface Prescription {
  id: string;
  patientId: string;
  doctorId: string;
  date: string;
  medications: {
    medicationName: string;
    dosage: string;
    frequency: string;
    duration: string;
    notes?: string;
  }[];
  diagnosis: string;
  instructions?: string;
  status: 'created' | 'sent' | 'filled' | 'completed';
}

export interface MedicalRecord {
  id: string;
  patientId: string;
  doctorId: string;
  date: string;
  type: 'visit' | 'lab' | 'surgery' | 'other';
  title: string;
  description: string;
  attachments?: string[]; // URLs to files
  status: 'active' | 'archived';
}

export interface Medication {
  id: string;
  name: string;
  description: string;
  dosageForm: string; // e.g., tablet, capsule, liquid
  strength: string; // e.g., 500mg, 10ml
  manufacturer: string;
  stockQuantity: number;
  unitPrice: number;
}

export interface Dashboard {
  appointmentsCount: number;
  patientsCount: number;
  upcomingAppointments: Appointment[];
  recentActivities: {
    id: string;
    type: 'appointment' | 'prescription' | 'record';
    description: string;
    timestamp: string;
    userId: string;
  }[];
}
