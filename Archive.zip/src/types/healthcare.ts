// Type definitions for the healthcare app

// User roles
export type UserRole = 'admin' | 'doctor' | 'patient' | 'pharmacist' | 'receptionist';

// User interface
export interface HealthcareUser {
  id: string;
  auth_id: string;
  email: string;
  password?: string; // Only used locally, would never include this in a real app
  first_name: string;
  last_name: string;
  role: UserRole;
  avatar_url: string | null;
  created_at: string;
  updated_at: string;
}

// Patient interface
export interface Patient {
  id: string;
  userId: string;
  dateOfBirth: string;
  gender: 'male' | 'female' | 'other';
  bloodType?: string;
  height?: number;
  weight?: number;
  allergies: string[];
  medicalConditions: string[];
  emergencyContact?: {
    name: string;
    relationship: string;
    contactNumber: string;
  };
  assignedDoctor?: string; // ID of the assigned doctor
  created_at: string;
  updated_at: string;
  // New field for reporting symptoms
  reportedSymptoms?: SymptomReport[];
  // New field to track if patient is new for each role
  newForRoles?: {
    admin: boolean;
    doctor: boolean;
    paramist: boolean;
  };
}

// Symptom report interface
export interface SymptomReport {
  id: string;
  patientId: string;
  description: string;
  severity: 'mild' | 'moderate' | 'severe';
  duration: string; // e.g., "2 days", "1 week"
  status: 'reported' | 'reviewed' | 'addressed';
  created_at: string;
  updated_at: string;
}

// Doctor interface
export interface Doctor {
  id: string;
  userId: string;
  specialization: string;
  licenseNumber: string;
  yearsOfExperience: number;
  education: string;
  schedule?: {
    monday: string[];
    tuesday: string[];
    wednesday: string[];
    thursday: string[];
    friday: string[];
    saturday: string[];
    sunday: string[];
  };
  created_at: string;
  updated_at: string;
  availability?: 'available' | 'busy' | 'unavailable';
  patientCount?: number;
}

// Appointment interface
export interface Appointment {
  id: string;
  patientId: string;
  doctorId: string;
  date: string;
  startTime: string;
  endTime: string;
  reason: string;
  notes?: string;
  status: 'scheduled' | 'cancelled' | 'completed'; 
  created_at: string;
  updated_at: string;
  symptoms?: string; // Field to store related symptoms
}

// Prescription interface
export interface Prescription {
  id: string;
  patientId: string;
  doctorId: string;
  date: string;
  diagnosis: string;
  medications: {
    medicationId: string;
    medicationName: string;
    dosage: string;
    frequency: string;
    duration: string;
    notes?: string;
  }[];
  instructions?: string;
  status: 'created' | 'sent' | 'filled' | 'completed';
  created_at: string;
  updated_at: string;
}

// Medical record interface
export interface MedicalRecord {
  id: string;
  patientId: string;
  doctorId: string;
  date: string;
  title: string;
  description: string;
  type: 'visit' | 'lab' | 'procedure' | 'other';
  status: 'active' | 'archived';
  attachments?: string[];
  created_at: string;
  updated_at: string;
  relatedSymptoms?: string[]; // Field to link symptoms to records
}

// Medication interface
export interface Medication {
  id: string;
  name: string;
  description: string;
  manufacturer: string;
  dosageForm: string;
  strength: string;
  category?: string;
  requiresPrescription?: boolean;
  stockAvailable?: boolean;
  created_at: string;
  updated_at: string;
}

// Message interface for chat functionality
export interface ChatMessage {
  id: string;
  senderId: string;
  recipientId: string;
  content: string;
  read: boolean;
  created_at: string;
}

// Auth context types
export interface AuthContextType {
  user: HealthcareUser | null;
  session: any;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  signup: (email: string, password: string, userData: Partial<HealthcareUser>) => Promise<void>;
}

// Dashboard data types
export interface DashboardData {
  appointmentsCount: number;
  patientsCount: number;
  upcomingAppointments: Appointment[];
  recentActivities: Activity[];
  activeCasesCount: number; // Number of active cases (patients under care)
  pendingTasksCount: number; // Number of pending tasks (e.g., scheduled appointments, unfilled prescriptions)
}

export interface Activity {
  id: string;
  type: 'appointment' | 'prescription' | 'record' | 'message' | 'symptom';
  description: string;
  timestamp: string;
}

// Analytics data types
export interface AnalyticsData {
  appointmentsTrend: MonthlyData[];
  patientDemographics: DemographicData[];
  revenueData: MonthlyData[];
}

export interface MonthlyData {
  month: string;
  appointments?: number;
  revenue?: number;
}

export interface DemographicData {
  name: string;
  value: number;
}
