import { useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import { initializeLocalStorage } from "./services/localStorageService";
import { initializeDefaultMessages } from "./services/chatService";

// Layouts
import AppLayout from "@/components/layout/AppLayout";
import NotFound from "@/pages/NotFound";

// Pages
import Login from "@/pages/Login";
import Dashboard from "@/pages/Dashboard";
import Appointments from "@/pages/Appointments";
import MedicalRecords from "@/pages/MedicalRecords";
import Patients from "@/pages/Patients";
import Prescriptions from "@/pages/Prescriptions";
import Analytics from "@/pages/Analytics";
import Chat from "@/pages/Chat";
import Schedule from "@/pages/Schedule";
import Settings from "@/pages/Settings";

function App() {
  useEffect(() => {
    // Initialize all storage with empty data
    initializeLocalStorage();
    initializeDefaultMessages();
  }, []);

  return (
    <AuthProvider>
      <TooltipProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<Navigate to="/dashboard" replace />} />

          {/* Protected Routes */}
          <Route path="/" element={<AppLayout />}>
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="appointments" element={<Appointments />} />
            <Route path="medical-records" element={<MedicalRecords />} />
            <Route path="patients" element={<Patients />} />
            <Route path="prescriptions" element={<Prescriptions />} />
            <Route path="analytics" element={<Analytics />} />
            <Route path="chat" element={<Chat />} />
            <Route path="schedule" element={<Schedule />} />
            <Route path="settings" element={<Settings />} />
          </Route>

          {/* Catch-all route for 404 */}
          <Route path="*" element={<NotFound />} />
        </Routes>
        <Toaster />
        <Sonner />
      </TooltipProvider>
    </AuthProvider>
  );
}

export default App;
